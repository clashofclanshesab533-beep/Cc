const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { Docker } = require('dockerode');
const pty = require('node-pty');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const redis = require('redis');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const winston = require('winston');
const { v4: uuidv4 } = require('uuid');

require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

const PORT = process.env.PORT || 8000;
const DOCKER_SOCKET = process.env.DOCKER_SOCKET || '/var/run/docker.sock';
const CONTAINER_NETWORK = process.env.CONTAINER_NETWORK || 'cybersec_network';
const MAX_CONTAINERS_PER_USER = parseInt(process.env.MAX_CONTAINERS_PER_USER || '5');
const CONTAINER_TIMEOUT = parseInt(process.env.CONTAINER_TIMEOUT || '3600');

// Logger configuration
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

// Docker connection
const docker = new Docker({ socketPath: DOCKER_SOCKET });

// PostgreSQL connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Redis connection
const redisClient = redis.createClient({
  url: process.env.REDIS_URL
});

redisClient.connect().catch(err => {
  logger.error('Redis connection error:', err);
});

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});

app.use(generalLimiter);

// Store active container sessions
const activeSessions = new Map();

// Helper functions
const verifyToken = (token) => {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    return { valid: true, userId: decoded.userId };
  } catch (error) {
    return { valid: false, error: 'Invalid token' };
  }
};

const createContainer = async (userId, module_id, challenge_id, image, port = null) => {
  try {
    // Check user's active containers
    const userContainers = Array.from(activeSessions.values())
      .filter(session => session.userId === userId);

    if (userContainers.length >= MAX_CONTAINERS_PER_USER) {
      throw new Error('Maximum container limit reached');
    }

    const sessionId = uuidv4();
    const containerName = `cybersec_${userId}_${sessionId.substring(0, 8)}`;

    // Port bindings
    const PortBindings = {};
    const ExposedPorts = {};
    
    if (port) {
      const hostPort = await getAvailablePort();
      PortBindings[`${port}/tcp`] = [{ HostPort: hostPort.toString() }];
      ExposedPorts[`${port}/tcp`] = {};
    }

    // Create container
    const containerConfig = {
      name: containerName,
      Image: image,
      ExposedPorts,
      HostConfig: {
        PortBindings,
        NetworkMode: CONTAINER_NETWORK,
        Memory: 512 * 1024 * 1024, // 512MB
        CpuShares: 512,
        AutoRemove: false,
        LogConfig: {
          Type: 'json-file',
          Config: {
            'max-size': '10m',
            'max-file': '3'
          }
        }
      },
      Labels: {
        'cybersec.user_id': userId,
        'cybersec.session_id': sessionId,
        'cybersec.module_id': module_id || '',
        'cybersec.challenge_id': challenge_id || ''
      }
    };

    const container = await docker.createContainer(containerConfig);
    await container.start();

    // Get container info
    const containerInfo = await container.inspect();

    // Store session
    const sessionData = {
      sessionId,
      userId,
      module_id,
      challenge_id,
      containerId: container.id,
      containerName,
      createdAt: new Date(),
      portMapping: port ? { internal: port, external: parseInt(Object.values(PortBindings)[0][0].HostPort) } : null,
      container
    };

    activeSessions.set(sessionId, sessionData);

    // Save to database
    await pool.query(
      `INSERT INTO container_sessions 
       (id, user_id, module_id, challenge_id, container_id, container_name, status, port_mapping) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        sessionId,
        userId,
        module_id,
        challenge_id,
        container.id,
        containerName,
        'running',
        JSON.stringify(sessionData.portMapping)
      ]
    );

    // Set timeout for auto-stop
    setTimeout(() => {
      stopContainer(sessionId).catch(err => 
        logger.error(`Auto-stop error for session ${sessionId}:`, err)
      );
    }, CONTAINER_TIMEOUT * 1000);

    // Cache in Redis
    await redisClient.setEx(`container:${sessionId}`, CONTAINER_TIMEOUT, JSON.stringify(sessionData));

    logger.info(`Container created: ${containerName} for user ${userId}`);

    return sessionData;
  } catch (error) {
    logger.error('Container creation error:', error);
    throw error;
  }
};

const stopContainer = async (sessionId) => {
  try {
    const session = activeSessions.get(sessionId);
    if (!session) {
      return;
    }

    await session.container.stop({ t: 5 });
    await session.container.remove();

    // Update database
    await pool.query(
      `UPDATE container_sessions 
       SET status = 'stopped', stopped_at = CURRENT_TIMESTAMP 
       WHERE id = $1`,
      [sessionId]
    );

    // Remove from cache
    await redisClient.del(`container:${sessionId}`);

    activeSessions.delete(sessionId);

    logger.info(`Container stopped: ${session.containerName}`);
  } catch (error) {
    logger.error(`Container stop error for session ${sessionId}:`, error);
  }
};

const getAvailablePort = async () => {
  const usedPorts = Array.from(activeSessions.values())
    .filter(session => session.portMapping)
    .map(session => session.portMapping.external);

  for (let port = 8000; port < 9000; port++) {
    if (!usedPorts.includes(port)) {
      return port;
    }
  }
  throw new Error('No available ports');
};

const executeCommand = async (container, command) => {
  try {
    const exec = await container.exec({
      Cmd: ['/bin/sh', '-c', command],
      AttachStdout: true,
      AttachStderr: true,
      Tty: false
    });

    const stream = await exec.start({ Detach: false });
    let output = '';

    return new Promise((resolve, reject) => {
      stream.on('data', (chunk) => {
        output += chunk.toString();
      });

      stream.on('error', reject);

      stream.on('end', () => {
        exec.inspect((err, data) => {
          if (err) {
            reject(err);
          } else {
            resolve({ output, exitCode: data.ExitCode });
          }
        });
      });
    });
  } catch (error) {
    logger.error('Command execution error:', error);
    throw error;
  }
};

// WebSocket connection handler
wss.on('connection', async (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  const sessionId = url.searchParams.get('session_id');

  if (!token || !sessionId) {
    ws.close(1008, 'Token and session_id required');
    return;
  }

  // Verify token
  const { valid, userId, error } = verifyToken(token);
  if (!valid) {
    ws.close(1008, error || 'Invalid token');
    return;
  }

  // Get session
  const session = activeSessions.get(sessionId);
  if (!session) {
    ws.close(1008, 'Invalid session');
    return;
  }

  if (session.userId !== userId) {
    ws.close(1008, 'Unauthorized');
    return;
  }

  logger.info(`WebSocket connection established for session ${sessionId}`);

  // Create PTY
  const ptyProcess = pty.spawn('/bin/bash', [], {
    name: 'xterm-color',
    cols: 80,
    rows: 24,
    cwd: '/home/user',
    env: process.env
  });

  // Execute PTY in container
  const exec = await session.container.exec({
    Cmd: ['docker', 'exec', '-it', session.containerName, '/bin/bash'],
    AttachStdin: true,
    AttachStdout: true,
    AttachStderr: true,
    Tty: true
  });

  const stream = await exec.start({ Detach: false });

  // Forward data between WebSocket and PTY
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      
      if (data.type === 'input') {
        stream.write(data.input);
      } else if (data.type === 'resize') {
        ptyProcess.resize(data.cols, data.rows);
        exec.resize({ h: data.rows, w: data.cols });
      }
    } catch (error) {
      logger.error('WebSocket message error:', error);
    }
  });

  stream.on('data', (data) => {
    ws.send(JSON.stringify({ type: 'output', output: data.toString() }));
  });

  ws.on('close', () => {
    stream.end();
    ptyProcess.destroy();
    logger.info(`WebSocket connection closed for session ${sessionId}`);
  });

  ws.on('error', (error) => {
    logger.error(`WebSocket error for session ${sessionId}:`, error);
  });
});

// REST API Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'terminal-service', 
    activeSessions: activeSessions.size,
    timestamp: new Date().toISOString() 
  });
});

// Create container
app.post('/containers', async (req, res) => {
  try {
    const { token, module_id, challenge_id, image, port } = req.body;

    if (!token || !image) {
      return res.status(400).json({ error: 'Token and image required' });
    }

    const { valid, userId, error } = verifyToken(token);
    if (!valid) {
      return res.status(401).json({ error });
    }

    const session = await createContainer(userId, module_id, challenge_id, image, port);

    res.json({
      message: 'Container created successfully',
      sessionId: session.sessionId,
      containerName: session.containerName,
      portMapping: session.portMapping,
      wsUrl: `ws://localhost/ws?token=${token}&session_id=${session.sessionId}`
    });
  } catch (error) {
    logger.error('Container creation API error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Stop container
app.delete('/containers/:sessionId', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Token required' });
    }

    const { valid, userId, error } = verifyToken(token);
    if (!valid) {
      return res.status(401).json({ error });
    }

    const session = activeSessions.get(req.params.sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.userId !== userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await stopContainer(req.params.sessionId);

    res.json({ message: 'Container stopped successfully' });
  } catch (error) {
    logger.error('Container stop API error:', error);
    res.status(500).json({ error: error.message });
  }
});

// List user containers
app.get('/containers', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Token required' });
    }

    const { valid, userId, error } = verifyToken(token);
    if (!valid) {
      return res.status(401).json({ error });
    }

    const userContainers = Array.from(activeSessions.values())
      .filter(session => session.userId === userId)
      .map(session => ({
        sessionId: session.sessionId,
        containerName: session.containerName,
        createdAt: session.createdAt,
        portMapping: session.portMapping
      }));

    res.json({ containers: userContainers });
  } catch (error) {
    logger.error('List containers API error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Execute command in container
app.post('/containers/:sessionId/exec', async (req, res) => {
  try {
    const { token, command } = req.body;

    if (!token || !command) {
      return res.status(400).json({ error: 'Token and command required' });
    }

    const { valid, userId, error } = verifyToken(token);
    if (!valid) {
      return res.status(401).json({ error });
    }

    const session = activeSessions.get(req.params.sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.userId !== userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const result = await executeCommand(session.container, command);

    res.json({ output: result.output, exitCode: result.exitCode });
  } catch (error) {
    logger.error('Command execution API error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get container logs
app.get('/containers/:sessionId/logs', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Token required' });
    }

    const { valid, userId, error } = verifyToken(token);
    if (!valid) {
      return res.status(401).json({ error });
    }

    const session = activeSessions.get(req.params.sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.userId !== userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const logs = await session.container.logs({
      stdout: true,
      stderr: true,
      tail: 100
    });

    res.json({ logs: logs.toString() });
  } catch (error) {
    logger.error('Get logs API error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
server.listen(PORT, () => {
  logger.info(`Terminal Service running on port ${PORT}`);
});

// Cleanup on shutdown
const cleanup = async () => {
  logger.info('Cleaning up containers...');
  
  for (const [sessionId, session] of activeSessions) {
    try {
      await session.container.stop({ t: 5 });
      await session.container.remove();
    } catch (error) {
      logger.error(`Error stopping container ${session.containerName}:`, error);
    }
  }
  
  activeSessions.clear();
  await pool.end();
  await redisClient.quit();
  logger.info('Cleanup complete');
};

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  await cleanup();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully');
  await cleanup();
  process.exit(0);
});