package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"github.com/golang-jwt/jwt/v4"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

var (
	ctx           context.Context
	dbPool        *pgxpool.Pool
	redisClient   *redis.Client
	jwtSecret     []byte
)

type Challenge struct {
	ID          string   `json:"id"`
	Title       string   `json:"title"`
	Slug        string   `json:"slug"`
	Description string   `json:"description"`
	Category    string   `json:"category"`
	Difficulty  string   `json:"difficulty"`
	Points      int      `json:"points"`
	DockerImage string   `json:"docker_image,omitempty"`
	Port        *int     `json:"port,omitempty"`
	Hints       []string `json:"hints,omitempty"`
	IsPublished bool     `json:"is_published"`
}

type Submission struct {
	ID            string    `json:"id"`
	UserID        string    `json:"user_id"`
	ChallengeID   string    `json:"challenge_id"`
	FlagSubmitted string    `json:"flag_submitted"`
	IsCorrect     bool      `json:"is_correct"`
	SubmittedAt   time.Time `json:"submitted_at"`
}

type Team struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	CaptainID   string `json:"captain_id"`
	MaxMembers  int    `json:"max_members"`
	Description string `json:"description"`
}

type LeaderboardEntry struct {
	UserID            string `json:"user_id,omitempty"`
	TeamID            string `json:"team_id,omitempty"`
	Username          string `json:"username,omitempty"`
	TeamName          string `json:"team_name,omitempty"`
	Score             int    `json:"score"`
	ChallengesSolved  int    `json:"challenges_solved"`
}

func init() {
	ctx = context.Background()
	jwtSecret = []byte(os.Getenv("JWT_SECRET"))
	if len(jwtSecret) == 0 {
		jwtSecret = []byte("your-secret-key-change-in-production")
	}

	// PostgreSQL connection
	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" {
		dbURL = "postgres://cybersec:password@postgres:5432/cybersec"
	}

	var err error
	dbPool, err = pgxpool.New(ctx, dbURL)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}

	// Redis connection
	redisURL := os.Getenv("REDIS_URL")
	if redisURL == "" {
		redisURL = "redis://redis:6379"
	}

	redisClient = redis.NewClient(&redis.Options{
		Addr:     "redis:6379",
		Password: "",
		DB:       0,
	})

	if err := redisClient.Ping(ctx).Err(); err != nil {
		log.Printf("Redis connection error: %v", err)
	}
}

func main() {
	router := gin.Default()

	// Middleware
	router.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Authorization")
		
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// Public routes
	router.GET("/health", healthCheck)
	router.GET("/challenges", listChallenges)
	router.GET("/challenges/:id", getChallenge)
	router.GET("/leaderboard", getLeaderboard)
	router.GET("/leaderboard/teams", getTeamLeaderboard)

	// Protected routes
	protected := router.Group("/")
	protected.Use(authMiddleware())
	{
		protected.POST("/submissions", submitFlag)
		protected.GET("/submissions/user", getUserSubmissions)
		protected.GET("/challenges/:id/solved", isChallengeSolved)
		protected.POST("/teams", createTeam)
		protected.GET("/teams/:id", getTeam)
		protected.PUT("/teams/:id/members", joinTeam)
		protected.DELETE("/teams/:id/members", leaveTeam)
	}

	router.Run(":8000")
}

func authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Authorization header required"})
			c.Abort()
			return
		}

		tokenString := authHeader
		if len(authHeader) > 7 && authHeader[:7] == "Bearer " {
			tokenString = authHeader[7:]
		}

		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
			}
			return jwtSecret, nil
		})

		if err != nil || !token.Valid {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
			c.Abort()
			return
		}

		if claims, ok := token.Claims.(jwt.MapClaims); ok {
			c.Set("userId", claims["userId"])
		}

		c.Next()
	}
}

func healthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "healthy",
		"service":   "ctf-service",
		"timestamp": time.Now().UTC().Format(time.RFC3339),
	})
}

func listChallenges(c *gin.Context) {
	category := c.Query("category")
	difficulty := c.Query("difficulty")
	publishedOnly := c.DefaultQuery("published", "true") == "true"

	query := `SELECT id, title, slug, description, category, difficulty, points, 
	          docker_image, port, is_published FROM ctf_challenges WHERE 1=1`
	args := []interface{}{}
	argIndex := 1

	if category != "" {
		query += fmt.Sprintf(" AND category = $%d", argIndex)
		args = append(args, category)
		argIndex++
	}

	if difficulty != "" {
		query += fmt.Sprintf(" AND difficulty = $%d", argIndex)
		args = append(args, difficulty)
		argIndex++
	}

	if publishedOnly {
		query += fmt.Sprintf(" AND is_published = $%d", argIndex)
		args = append(args, true)
		argIndex++
	}

	query += " ORDER BY points ASC"

	rows, err := dbPool.Query(ctx, query, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch challenges"})
		return
	}
	defer rows.Close()

	challenges := []Challenge{}
	for rows.Next() {
		var ch Challenge
		err := rows.Scan(
			&ch.ID, &ch.Title, &ch.Slug, &ch.Description,
			&ch.Category, &ch.Difficulty, &ch.Points,
			&ch.DockerImage, &ch.Port, &ch.IsPublished,
		)
		if err != nil {
			log.Printf("Error scanning challenge: %v", err)
			continue
		}
		
		// Don't expose Docker image and port in list view
		if publishedOnly {
			ch.DockerImage = ""
			ch.Port = nil
		}
		
		challenges = append(challenges, ch)
	}

	c.JSON(http.StatusOK, gin.H{"challenges": challenges})
}

func getChallenge(c *gin.Context) {
	id := c.Param("id")

	var ch Challenge
	query := `SELECT id, title, slug, description, category, difficulty, points, 
	          docker_image, port, hints, is_published FROM ctf_challenges WHERE id = $1`

	err := dbPool.QueryRow(ctx, query, id).Scan(
		&ch.ID, &ch.Title, &ch.Slug, &ch.Description,
		&ch.Category, &ch.Difficulty, &ch.Points,
		&ch.DockerImage, &ch.Port,
		&ch.Hints, &ch.IsPublished,
	)

	if err == pgx.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Challenge not found"})
		return
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch challenge"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"challenge": ch})
}

func submitFlag(c *gin.Context) {
	userID := c.GetString("userId")
	
	var req struct {
		ChallengeID string `json:"challenge_id" binding:"required"`
		Flag        string `json:"flag" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Get challenge flag
	var correctFlag string
	var maxAttempts int
	err := dbPool.QueryRow(ctx, 
		"SELECT flag, max_attempts FROM ctf_challenges WHERE id = $1", 
		req.ChallengeID).Scan(&correctFlag, &maxAttempts)

	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Challenge not found"})
		return
	}

	// Check attempt limit
	var attempts int
	dbPool.QueryRow(ctx,
		"SELECT COUNT(*) FROM ctf_submissions WHERE user_id = $1 AND challenge_id = $2",
		userID, req.ChallengeID).Scan(&attempts)

	if attempts >= maxAttempts {
		c.JSON(http.StatusTooManyRequests, gin.H{"error": "Maximum attempts reached"})
		return
	}

	// Validate flag
	isCorrect := req.Flag == correctFlag

	// Record submission
	submissionID := uuid()
	_, err = dbPool.Exec(ctx,
		`INSERT INTO ctf_submissions (id, user_id, challenge_id, flag_submitted, is_correct, submitted_at)
		 VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)`,
		submissionID, userID, req.ChallengeID, req.Flag, isCorrect)

	if err != nil {
		log.Printf("Failed to record submission: %v", err)
	}

	// If correct, update leaderboard
	if isCorrect {
		// Check if already solved
		var solvedCount int
		dbPool.QueryRow(ctx,
			"SELECT COUNT(*) FROM ctf_submissions WHERE user_id = $1 AND challenge_id = $2 AND is_correct = true",
			userID, req.ChallengeID).Scan(&solvedCount)

		if solvedCount == 1 { // First time solving
			// Update user score
			var currentScore int
			dbPool.QueryRow(ctx, "SELECT COALESCE(score, 0) FROM leaderboard WHERE user_id = $1", userID).Scan(&currentScore)
			
			var challengesSolved int
			dbPool.QueryRow(ctx,
				"SELECT COUNT(DISTINCT challenge_id) FROM ctf_submissions WHERE user_id = $1 AND is_correct = true",
				userID).Scan(&challengesSolved)

			newScore := currentScore + // Get challenge points
			dbPool.QueryRow(ctx, "SELECT points FROM ctf_challenges WHERE id = $1", req.ChallengeID).Scan(&currentScore)

			_, err = dbPool.Exec(ctx,
				`INSERT INTO leaderboard (id, user_id, score, challenges_solved, last_updated)
				 VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
				 ON CONFLICT (user_id) DO UPDATE
				 SET score = leaderboard.score + $3,
				     challenges_solved = $4,
				     last_updated = CURRENT_TIMESTAMP`,
				uuid(), userID, currentScore, challengesSolved)

			if err != nil {
				log.Printf("Failed to update leaderboard: %v", err)
			}

			// Invalidate leaderboard cache
			redisClient.Del(ctx, "leaderboard:users")
			redisClient.Del(ctx, "leaderboard:teams")
		}
	}

	response := gin.H{
		"correct": isCorrect,
		"message": "Flag submitted successfully",
	}

	if !isCorrect {
		response["hint"] = "Incorrect flag, try again"
	}

	c.JSON(http.StatusOK, response)
}

func getUserSubmissions(c *gin.Context) {
	userID := c.GetString("userId")

	rows, err := dbPool.Query(ctx,
		`SELECT id, challenge_id, flag_submitted, is_correct, submitted_at
		 FROM ctf_submissions WHERE user_id = $1 ORDER BY submitted_at DESC`,
		userID)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch submissions"})
		return
	}
	defer rows.Close()

	submissions := []Submission{}
	for rows.Next() {
		var sub Submission
		err := rows.Scan(&sub.ID, &sub.ChallengeID, &sub.FlagSubmitted, &sub.IsCorrect, &sub.SubmittedAt)
		if err != nil {
			log.Printf("Error scanning submission: %v", err)
			continue
		}
		submissions = append(submissions, sub)
	}

	c.JSON(http.StatusOK, gin.H{"submissions": submissions})
}

func getLeaderboard(c *gin.Context) {
	// Try cache first
	cached, err := redisClient.Get(ctx, "leaderboard:users").Result()
	if err == nil && cached != "" {
		var entries []LeaderboardEntry
		json.Unmarshal([]byte(cached), &entries)
		c.JSON(http.StatusOK, gin.H{"leaderboard": entries})
		return
	}

	query := `
		SELECT l.user_id, u.username, l.score, l.challenges_solved
		FROM leaderboard l
		LEFT JOIN users u ON l.user_id = u.id
		WHERE l.user_id IS NOT NULL
		ORDER BY l.score DESC, l.last_updated ASC
		LIMIT 100
	`

	rows, err := dbPool.Query(ctx, query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch leaderboard"})
		return
	}
	defer rows.Close()

	entries := []LeaderboardEntry{}
	rank := 1
	for rows.Next() {
		var entry LeaderboardEntry
		err := rows.Scan(&entry.UserID, &entry.Username, &entry.Score, &entry.ChallengesSolved)
		if err != nil {
			log.Printf("Error scanning leaderboard entry: %v", err)
			continue
		}
		entries = append(entries, entry)
		rank++
	}

	// Cache for 5 minutes
	cachedData, _ := json.Marshal(entries)
	redisClient.Set(ctx, "leaderboard:users", cachedData, 5*time.Minute)

	c.JSON(http.StatusOK, gin.H{"leaderboard": entries})
}

func getTeamLeaderboard(c *gin.Context) {
	// Try cache first
	cached, err := redisClient.Get(ctx, "leaderboard:teams").Result()
	if err == nil && cached != "" {
		var entries []LeaderboardEntry
		json.Unmarshal([]byte(cached), &entries)
		c.JSON(http.StatusOK, gin.H{"leaderboard": entries})
		return
	}

	query := `
		SELECT l.team_id, t.name, l.score, l.challenges_solved
		FROM leaderboard l
		LEFT JOIN ctf_teams t ON l.team_id = t.id
		WHERE l.team_id IS NOT NULL
		ORDER BY l.score DESC, l.last_updated ASC
		LIMIT 100
	`

	rows, err := dbPool.Query(ctx, query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch team leaderboard"})
		return
	}
	defer rows.Close()

	entries := []LeaderboardEntry{}
	for rows.Next() {
		var entry LeaderboardEntry
		err := rows.Scan(&entry.TeamID, &entry.TeamName, &entry.Score, &entry.ChallengesSolved)
		if err != nil {
			log.Printf("Error scanning team leaderboard entry: %v", err)
			continue
		}
		entries = append(entries, entry)
	}

	// Cache for 5 minutes
	cachedData, _ := json.Marshal(entries)
	redisClient.Set(ctx, "leaderboard:teams", cachedData, 5*time.Minute)

	c.JSON(http.StatusOK, gin.H{"leaderboard": entries})
}

func isChallengeSolved(c *gin.Context) {
	userID := c.GetString("userId")
	challengeID := c.Param("id")

	var count int
	err := dbPool.QueryRow(ctx,
		"SELECT COUNT(*) FROM ctf_submissions WHERE user_id = $1 AND challenge_id = $2 AND is_correct = true",
		userID, challengeID).Scan(&count)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to check challenge status"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"solved": count > 0})
}

func createTeam(c *gin.Context) {
	userID := c.GetString("userId")
	
	var req struct {
		Name        string `json:"name" binding:"required"`
		Description string `json:"description"`
		MaxMembers  int    `json:"max_members"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if req.MaxMembers == 0 {
		req.MaxMembers = 5
	}

	teamID := uuid()
	_, err := dbPool.Exec(ctx,
		`INSERT INTO ctf_teams (id, name, captain_id, max_members, description, created_at)
		 VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)`,
		teamID, req.Name, userID, req.MaxMembers, req.Description)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create team"})
		return
	}

	// Add captain as member
	_, err = dbPool.Exec(ctx,
		"INSERT INTO team_members (team_id, user_id, joined_at) VALUES ($1, $2, CURRENT_TIMESTAMP)",
		teamID, userID)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to add captain to team"})
		return
	}

	c.JSON(http.StatusCreated, gin.H{
		"message": "Team created successfully",
		"team_id": teamID,
	})
}

func getTeam(c *gin.Context) {
	teamID := c.Param("id")

	var team Team
	err := dbPool.QueryRow(ctx,
		"SELECT id, name, captain_id, max_members, description FROM ctf_teams WHERE id = $1",
		teamID).Scan(&team.ID, &team.Name, &team.CaptainID, &team.MaxMembers, &team.Description)

	if err == pgx.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Team not found"})
		return
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch team"})
		return
	}

	// Get team members
	rows, err := dbPool.Query(ctx,
		`SELECT u.id, u.username, tm.joined_at
		 FROM team_members tm
		 LEFT JOIN users u ON tm.user_id = u.id
		 WHERE tm.team_id = $1`,
		teamID)

	if err == nil {
		members := []map[string]interface{}{}
		for rows.Next() {
			var memberID, username string
			var joinedAt time.Time
			rows.Scan(&memberID, &username, &joinedAt)
			members = append(members, map[string]interface{}{
				"user_id":    memberID,
				"username":   username,
				"joined_at":  joinedAt,
			})
		}
		rows.Close()
	}

	c.JSON(http.StatusOK, gin.H{"team": team})
}

func joinTeam(c *gin.Context) {
	userID := c.GetString("userId")
	teamID := c.Param("id")

	// Check if user is already in a team
	var existingTeam string
	dbPool.QueryRow(ctx,
		"SELECT team_id FROM team_members WHERE user_id = $1",
		userID).Scan(&existingTeam)

	if existingTeam != "" {
		c.JSON(http.StatusConflict, gin.H{"error": "User is already in a team"})
		return
	}

	// Check team capacity
	var memberCount, maxMembers int
	dbPool.QueryRow(ctx,
		`SELECT COUNT(*), max_members 
		 FROM team_members tm
		 LEFT JOIN ctf_teams t ON tm.team_id = t.id
		 WHERE tm.team_id = $1
		 GROUP BY t.max_members`,
		teamID).Scan(&memberCount, &maxMembers)

	if memberCount >= maxMembers {
		c.JSON(http.StatusConflict, gin.H{"error": "Team is full"})
		return
	}

	_, err := dbPool.Exec(ctx,
		"INSERT INTO team_members (team_id, user_id, joined_at) VALUES ($1, $2, CURRENT_TIMESTAMP)",
		teamID, userID)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to join team"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Successfully joined team"})
}

func leaveTeam(c *gin.Context) {
	userID := c.GetString("userId")
	teamID := c.Param("id")

	result, err := dbPool.Exec(ctx,
		"DELETE FROM team_members WHERE team_id = $1 AND user_id = $2",
		teamID, userID)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to leave team"})
		return
	}

	if result.RowsAffected() == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Not a member of this team"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Successfully left team"})
}

func uuid() string {
	return fmt.Sprintf("%x", time.Now().UnixNano())
}