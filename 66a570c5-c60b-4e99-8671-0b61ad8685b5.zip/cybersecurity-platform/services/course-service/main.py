from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import create_engine, Column, String, Integer, Text, DateTime, Boolean, ForeignKey, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from sqlalchemy.dialects.postgresql import UUID
from pydantic import BaseModel
from typing import List, Optional, Any
import uuid
from datetime import datetime
from passlib.context import CryptContext
from jose import JWTError, jwt
import redis
import json
import os
import aiofiles
from pathlib import Path

# Configuration
class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://cybersec:password@postgres:5432/cybersec")
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://redis:6379")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "your-secret-key-change-in-production")
    AUTH_SERVICE_URL: str = os.getenv("AUTH_SERVICE_URL", "http://auth-service:8000")
    CONTENT_STORAGE_PATH: str = os.getenv("CONTENT_STORAGE_PATH", "/app/content")

settings = Settings()

# FastAPI app
app = FastAPI(title="Course Service", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Redis setup
redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)

# JWT Security
security = HTTPBearer()

# Create content directory
Path(settings.CONTENT_STORAGE_PATH).mkdir(parents=True, exist_ok=True)

# Database Models
class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    role = Column(String(20), default="student")

class Course(Base):
    __tablename__ = "courses"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String(255), nullable=False)
    slug = Column(String(255), unique=True, nullable=False)
    description = Column(Text)
    category = Column(String(100))
    difficulty = Column(String(20))
    estimated_hours = Column(Integer)
    prerequisites = Column(ARRAY(String))
    tags = Column(ARRAY(String))
    thumbnail_url = Column(Text)
    is_published = Column(Boolean, default=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    
    modules = relationship("Module", back_populates="course", cascade="all, delete-orphan")

class Module(Base):
    __tablename__ = "modules"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    course_id = Column(UUID(as_uuid=True), ForeignKey("courses.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    order_index = Column(Integer, nullable=False)
    estimated_minutes = Column(Integer)
    type = Column(String(20))
    content = Column(Text)  # JSON string
    docker_image = Column(String(255))
    resources = Column(Text)  # JSON array string
    is_free = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    
    course = relationship("Course", back_populates="modules")

# Create tables
Base.metadata.create_all(bind=engine)

# Pydantic Models
class CourseBase(BaseModel):
    title: str
    slug: str
    description: Optional[str] = None
    category: Optional[str] = None
    difficulty: Optional[str] = None
    estimated_hours: Optional[int] = None
    prerequisites: Optional[List[str]] = []
    tags: Optional[List[str]] = []
    thumbnail_url: Optional[str] = None

class CourseCreate(CourseBase):
    is_published: bool = False

class CourseUpdate(CourseBase):
    is_published: Optional[bool] = None

class CourseResponse(CourseBase):
    id: str
    is_published: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class ModuleBase(BaseModel):
    title: str
    description: Optional[str] = None
    order_index: int
    estimated_minutes: Optional[int] = None
    type: str
    content: Optional[dict] = None
    docker_image: Optional[str] = None
    resources: Optional[List[dict]] = []
    is_free: bool = False

class ModuleCreate(ModuleBase):
    course_id: str

class ModuleUpdate(ModuleBase):
    pass

class ModuleResponse(ModuleBase):
    id: str
    course_id: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Verify JWT token
async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    token = credentials.credentials
    
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])
        user_id = payload.get("userId")
        
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        return {"user_id": user_id, "role": payload.get("role", "student")}
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

# Check if user is instructor or admin
def check_instructor_or_admin(user_info: dict):
    if user_info["role"] not in ["instructor", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only instructors and admins can perform this action"
        )

# Health check
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "course-service",
        "timestamp": datetime.utcnow().isoformat()
    }

# Course endpoints
@app.get("/courses", response_model=List[CourseResponse])
async def list_courses(
    category: Optional[str] = None,
    difficulty: Optional[str] = None,
    published_only: bool = True,
    db: Session = Depends(get_db)
):
    query = db.query(Course)
    
    if published_only:
        query = query.filter(Course.is_published == True)
    
    if category:
        query = query.filter(Course.category == category)
    
    if difficulty:
        query = query.filter(Course.difficulty == difficulty)
    
    courses = query.order_by(Course.created_at.desc()).all()
    
    return [
        CourseResponse(
            id=str(course.id),
            title=course.title,
            slug=course.slug,
            description=course.description,
            category=course.category,
            difficulty=course.difficulty,
            estimated_hours=course.estimated_hours,
            prerequisites=course.prerequisites or [],
            tags=course.tags or [],
            thumbnail_url=course.thumbnail_url,
            is_published=course.is_published,
            created_at=course.created_at,
            updated_at=course.updated_at
        )
        for course in courses
    ]

@app.get("/courses/{course_id}", response_model=CourseResponse)
async def get_course(course_id: str, db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == uuid.UUID(course_id)).first()
    
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    
    return CourseResponse(
        id=str(course.id),
        title=course.title,
        slug=course.slug,
        description=course.description,
        category=course.category,
        difficulty=course.difficulty,
        estimated_hours=course.estimated_hours,
        prerequisites=course.prerequisites or [],
        tags=course.tags or [],
        thumbnail_url=course.thumbnail_url,
        is_published=course.is_published,
        created_at=course.created_at,
        updated_at=course.updated_at
    )

@app.get("/courses/{course_id}/modules", response_model=List[ModuleResponse])
async def get_course_modules(course_id: str, db: Session = Depends(get_db)):
    modules = db.query(Module).filter(
        Module.course_id == uuid.UUID(course_id)
    ).order_by(Module.order_index).all()
    
    return [
        ModuleResponse(
            id=str(module.id),
            course_id=str(module.course_id),
            title=module.title,
            description=module.description,
            order_index=module.order_index,
            estimated_minutes=module.estimated_minutes,
            type=module.type,
            content=json.loads(module.content) if module.content else {},
            docker_image=module.docker_image,
            resources=json.loads(module.resources) if module.resources else [],
            is_free=module.is_free,
            created_at=module.created_at,
            updated_at=module.updated_at
        )
        for module in modules
    ]

@app.post("/courses", response_model=CourseResponse, status_code=status.HTTP_201_CREATED)
async def create_course(
    course: CourseCreate,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    # Check if slug exists
    existing = db.query(Course).filter(Course.slug == course.slug).first()
    if existing:
        raise HTTPException(status_code=400, detail="Slug already exists")
    
    new_course = Course(
        title=course.title,
        slug=course.slug,
        description=course.description,
        category=course.category,
        difficulty=course.difficulty,
        estimated_hours=course.estimated_hours,
        prerequisites=course.prerequisites,
        tags=course.tags,
        thumbnail_url=course.thumbnail_url,
        is_published=course.is_published,
        created_by=uuid.UUID(user_info["user_id"])
    )
    
    db.add(new_course)
    db.commit()
    db.refresh(new_course)
    
    return CourseResponse(
        id=str(new_course.id),
        title=new_course.title,
        slug=new_course.slug,
        description=new_course.description,
        category=new_course.category,
        difficulty=new_course.difficulty,
        estimated_hours=new_course.estimated_hours,
        prerequisites=new_course.prerequisites or [],
        tags=new_course.tags or [],
        thumbnail_url=new_course.thumbnail_url,
        is_published=new_course.is_published,
        created_at=new_course.created_at,
        updated_at=new_course.updated_at
    )

@app.put("/courses/{course_id}", response_model=CourseResponse)
async def update_course(
    course_id: str,
    course_update: CourseUpdate,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    course = db.query(Course).filter(Course.id == uuid.UUID(course_id)).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    
    for field, value in course_update.dict(exclude_unset=True).items():
        setattr(course, field, value)
    
    course.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(course)
    
    return CourseResponse(
        id=str(course.id),
        title=course.title,
        slug=course.slug,
        description=course.description,
        category=course.category,
        difficulty=course.difficulty,
        estimated_hours=course.estimated_hours,
        prerequisites=course.prerequisites or [],
        tags=course.tags or [],
        thumbnail_url=course.thumbnail_url,
        is_published=course.is_published,
        created_at=course.created_at,
        updated_at=course.updated_at
    )

@app.delete("/courses/{course_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_course(
    course_id: str,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    course = db.query(Course).filter(Course.id == uuid.UUID(course_id)).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    
    db.delete(course)
    db.commit()
    
    return None

# Module endpoints
@app.get("/modules/{module_id}", response_model=ModuleResponse)
async def get_module(module_id: str, db: Session = Depends(get_db)):
    module = db.query(Module).filter(Module.id == uuid.UUID(module_id)).first()
    
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")
    
    return ModuleResponse(
        id=str(module.id),
        course_id=str(module.course_id),
        title=module.title,
        description=module.description,
        order_index=module.order_index,
        estimated_minutes=module.estimated_minutes,
        type=module.type,
        content=json.loads(module.content) if module.content else {},
        docker_image=module.docker_image,
        resources=json.loads(module.resources) if module.resources else [],
        is_free=module.is_free,
        created_at=module.created_at,
        updated_at=module.updated_at
    )

@app.post("/modules", response_model=ModuleResponse, status_code=status.HTTP_201_CREATED)
async def create_module(
    module: ModuleCreate,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    # Check if course exists
    course = db.query(Course).filter(Course.id == uuid.UUID(module.course_id)).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    
    new_module = Module(
        course_id=uuid.UUID(module.course_id),
        title=module.title,
        description=module.description,
        order_index=module.order_index,
        estimated_minutes=module.estimated_minutes,
        type=module.type,
        content=json.dumps(module.content) if module.content else None,
        docker_image=module.docker_image,
        resources=json.dumps(module.resources) if module.resources else None,
        is_free=module.is_free
    )
    
    db.add(new_module)
    db.commit()
    db.refresh(new_module)
    
    return ModuleResponse(
        id=str(new_module.id),
        course_id=str(new_module.course_id),
        title=new_module.title,
        description=new_module.description,
        order_index=new_module.order_index,
        estimated_minutes=new_module.estimated_minutes,
        type=new_module.type,
        content=json.loads(new_module.content) if new_module.content else {},
        docker_image=new_module.docker_image,
        resources=json.loads(new_module.resources) if new_module.resources else [],
        is_free=new_module.is_free,
        created_at=new_module.created_at,
        updated_at=new_module.updated_at
    )

@app.put("/modules/{module_id}", response_model=ModuleResponse)
async def update_module(
    module_id: str,
    module_update: ModuleUpdate,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    module = db.query(Module).filter(Module.id == uuid.UUID(module_id)).first()
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")
    
    for field, value in module_update.dict(exclude_unset=True).items():
        if field == "content" and value:
            setattr(module, field, json.dumps(value))
        elif field == "resources" and value:
            setattr(module, field, json.dumps(value))
        else:
            setattr(module, field, value)
    
    module.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(module)
    
    return ModuleResponse(
        id=str(module.id),
        course_id=str(module.course_id),
        title=module.title,
        description=module.description,
        order_index=module.order_index,
        estimated_minutes=module.estimated_minutes,
        type=module.type,
        content=json.loads(module.content) if module.content else {},
        docker_image=module.docker_image,
        resources=json.loads(module.resources) if module.resources else [],
        is_free=module.is_free,
        created_at=module.created_at,
        updated_at=module.updated_at
    )

@app.delete("/modules/{module_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_module(
    module_id: str,
    user_info: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    check_instructor_or_admin(user_info)
    
    module = db.query(Module).filter(Module.id == uuid.UUID(module_id)).first()
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")
    
    db.delete(module)
    db.commit()
    
    return None

# File upload endpoint
@app.post("/content/upload")
async def upload_content(
    file: UploadFile = File(...),
    user_info: dict = Depends(verify_token)
):
    check_instructor_or_admin(user_info)
    
    # Generate unique filename
    file_ext = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_ext}"
    file_path = Path(settings.CONTENT_STORAGE_PATH) / filename
    
    # Save file
    async with aiofiles.open(file_path, "wb") as f:
        content = await file.read()
        await f.write(content)
    
    return {
        "filename": filename,
        "url": f"/content/{filename}",
        "original_name": file.filename
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)