# Quick Start Guide

Get the CyberSec Learning Platform up and running in 5 minutes!

## Prerequisites

- Docker 20.10+
- Docker Compose 2.0+
- 8GB RAM
- 20GB disk space

## Installation

### Option 1: Automated Installation (Recommended)

```bash
# Clone the repository
git clone https://github.com/your-org/cybersecurity-platform.git
cd cybersecurity-platform

# Run the installation script
chmod +x install.sh
./install.sh
```

The script will:
1. Check system requirements
2. Create environment configuration
3. Build Docker images
4. Start all services
5. Initialize the database
6. Display access URLs

### Option 2: Manual Installation

```bash
# Clone the repository
git clone https://github.com/your-org/cybersecurity-platform.git
cd cybersecurity-platform

# Create environment file
cp .env.example .env

# Start services
docker-compose up -d

# Wait for services to be ready (about 2 minutes)
sleep 120

# Initialize database
docker-compose exec postgres psql -U cybersec -d cybersec -f /docker-entrypoint-initdb.d/init.sql
```

## Access the Platform

Once installation is complete, access the platform at:

- **Frontend**: http://localhost
- **API Gateway**: http://localhost/api
- **Grafana**: http://localhost:3001 (admin/admin)
- **Prometheus**: http://localhost:9090
- **Kibana**: http://localhost:5601
- **RabbitMQ**: http://localhost:15672 (guest/guest)

## Default Credentials

- **Username**: admin
- **Email**: admin@cybersec.platform
- **Password**: admin123

⚠️ **IMPORTANT**: Change the admin password immediately after first login!

## First Steps

### 1. Login
1. Go to http://localhost
2. Click "Login"
3. Enter admin credentials
4. You'll be redirected to the Dashboard

### 2. Change Password
1. Go to Profile page
2. Update your password
3. Save changes

### 3. Explore the Platform

#### Dashboard
- View your learning statistics
- See recent courses
- Check CTF progress
- Quick action buttons

#### Terminal
1. Navigate to Terminal page
2. Select a Docker image (e.g., Ubuntu, Kali Linux)
3. Click "Start Container"
4. Interact with the real terminal

#### Courses
1. Browse available courses
2. View course details
3. Start learning modules

#### CTF Challenges
1. View available challenges
2. Submit flags
3. Check leaderboard

## Common Commands

### View Service Status
```bash
docker-compose ps
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f auth-service
docker-compose logs -f terminal-service
```

### Restart Services
```bash
docker-compose restart
```

### Stop Services
```bash
docker-compose down
```

### Start Services
```bash
docker-compose up -d
```

### Rebuild Services
```bash
docker-compose build
docker-compose up -d
```

### Access Service Shell
```bash
# PostgreSQL
docker-compose exec postgres psql -U cybersec -d cybersec

# Redis
docker-compose exec redis redis-cli

# Auth Service
docker-compose exec auth-service sh
```

## Troubleshooting

### Services Won't Start

```bash
# Check what's wrong
docker-compose logs

# Check Docker daemon
docker info

# Restart Docker
sudo systemctl restart docker
```

### Database Connection Errors

```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Restart PostgreSQL
docker-compose restart postgres
```

### Port Already in Use

```bash
# Find what's using the port
lsof -i :80
lsof -i :5432

# Kill the process or change the port in docker-compose.yml
```

### Container Can't Connect to Docker Socket

```bash
# Check permissions
ls -l /var/run/docker.sock

# Fix permissions (development only)
sudo chmod 666 /var/run/docker.sock
```

## Development Setup

### Local Development without Docker

```bash
# Start PostgreSQL and Redis
docker run -d --name cybersec-postgres \
  -e POSTGRES_DB=cybersec \
  -e POSTGRES_USER=cybersec \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:15-alpine

docker run -d --name cybersec-redis \
  -p 6379:6379 \
  redis:7-alpine

# Initialize database
docker exec -i cybersec-postgres psql -U cybersec -d cybersec < infrastructure/sql/init.sql

# Install dependencies
cd frontend && npm install
cd ../services/auth-service && npm install
cd ../terminal-service && npm install
cd ../course-service && pip install -r requirements.txt
cd ../ctf-service && go mod download

# Start services in separate terminals
# Terminal 1: Auth Service
cd services/auth-service && npm run dev

# Terminal 2: Terminal Service
cd services/terminal-service && npm run dev

# Terminal 3: Course Service
cd services/course-service && uvicorn main:app --reload --port 8003

# Terminal 4: CTF Service
cd services/ctf-service && go run main.go

# Terminal 5: Frontend
cd frontend && npm start
```

## Production Deployment

For production deployment, see [DEPLOYMENT.md](docs/DEPLOYMENT.md)

Quick production setup:

```bash
# Update environment variables
nano .env.production

# Generate SSL certificates
mkdir -p docker/nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout docker/nginx/ssl/nginx.key \
  -out docker/nginx/ssl/nginx.crt

# Deploy to Docker Swarm
docker swarm init
docker stack deploy -c docker-compose.yml cybersecurity
```

## Next Steps

1. **Customize**: Update the platform to match your branding
2. **Add Content**: Create courses and CTF challenges
3. **Configure**: Set up monitoring and alerts
4. **Scale**: Deploy to production environment
5. **Secure**: Update all secrets and passwords

## Support

- 📖 Documentation: [README.md](README.md)
- 🏗️ Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- 🚀 Deployment: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)
- 📧 Email: support@cybersec.platform
- 💬 Discord: [Join our server](https://discord.gg/cybersec)

## What's Next?

After getting started, explore:

- **Creating Courses**: Build your own cybersecurity courses
- **Adding Challenges**: Create custom CTF challenges
- **Setting Up Labs**: Configure specialized lab environments
- **Integrating Tools**: Add external security tools
- **Customizing UI**: Modify the frontend to match your needs

Happy Learning! 🎓