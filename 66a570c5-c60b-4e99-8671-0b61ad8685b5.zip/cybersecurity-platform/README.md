# CyberSec Learning Platform

A comprehensive, production-ready cybersecurity learning platform featuring real terminal access, CTF challenges, and hands-on labs.

## 🚀 Features

- **Real Terminal Access**: Connect to actual Docker containers via WebSocket (not simulated)
- **CTF Platform**: Capture The Flag challenges with Red Team and Blue Team modules
- **Microservices Architecture**: Scalable, maintainable service-oriented design
- **Offline Capable**: Works offline with content caching and synchronization
- **Progress Tracking**: Detailed learning analytics and certificates
- **Team Collaboration**: Multiplayer CTF with team support
- **Role-Based Access**: Student, Instructor, and Admin roles

## 📋 Table of Contents

- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Development Setup](#development-setup)
- [Deployment](#deployment)
- [Configuration](#configuration)
- [Services](#services)
- [API Documentation](#api-documentation)
- [Contributing](#contributing)
- [License](#license)

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (React)                      │
└─────────────────────┬───────────────────────────────────────┘
                      │ HTTPS/WSS
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                      Nginx API Gateway                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Auth       │ │   User   │ │   Course     │
│  Service     │ │ Service  │ │   Service    │
└──────────────┘ └──────────┘ └──────────────┘
        │             │             │
        └─────────────┼─────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Terminal   │ │   CTF    │ │   Progress   │
│  Service     │ │ Service  │ │   Service    │
└──────────────┘ └──────────┘ └──────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Docker     │ │PostgreSQL│ │   Redis      │
│   Daemon     │ │          │ │              │
└──────────────┘ └──────────┘ └──────────────┘
```

## 🛠️ Tech Stack

### Frontend
- React 18+ with TypeScript
- Material-UI
- xterm.js (Terminal emulation)
- Socket.IO Client
- Redux Toolkit

### Backend
- Node.js (Auth, Terminal services)
- Python FastAPI (Course, User, Progress services)
- Go (CTF service)
- PostgreSQL
- Redis
- RabbitMQ

### Infrastructure
- Docker & Docker Compose
- Nginx (API Gateway)
- Prometheus + Grafana (Monitoring)
- ELK Stack (Logging)

## 📦 Prerequisites

- Docker 20.10+
- Docker Compose 2.0+
- Node.js 18+ (for local development)
- Python 3.11+ (for local development)
- Go 1.21+ (for local development)
- 8GB RAM minimum
- 50GB disk space

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/cybersecurity-platform.git
cd cybersecurity-platform
```

### 2. Environment Configuration

Create a `.env` file:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# JWT Secret (CHANGE THIS IN PRODUCTION!)
JWT_SECRET=your-super-secret-jwt-key-change-this

# Database Configuration
DATABASE_URL=postgresql://cybersec:password@postgres:5432/cybersec
POSTGRES_USER=cybersec
POSTGRES_PASSWORD=password

# Redis Configuration
REDIS_URL=redis://redis:6379

# Service URLs
AUTH_SERVICE_URL=http://auth-service:8000
USER_SERVICE_URL=http://user-service:8000
COURSE_SERVICE_URL=http://course-service:8000
CTF_SERVICE_URL=http://ctf-service:8000
TERMINAL_SERVICE_URL=http://terminal-service:8000
PROGRESS_SERVICE_URL=http://progress-service:8000

# Frontend Configuration
REACT_APP_API_URL=http://localhost:80/api
REACT_APP_WS_URL=ws://localhost:80/ws
```

### 3. Build and Start Services

```bash
# Build all services
docker-compose build

# Start all services
docker-compose up -d

# Check service status
docker-compose ps
```

### 4. Initialize Database

```bash
# Run database migrations
docker-compose exec postgres psql -U cybersec -d cybersec -f /docker-entrypoint-initdb.d/init.sql
```

### 5. Access the Platform

- **Frontend**: http://localhost:80
- **API Gateway**: http://localhost:80/api
- **Grafana**: http://localhost:3001 (admin/admin)
- **Kibana**: http://localhost:5601
- **RabbitMQ Management**: http://localhost:15672 (guest/guest)

### Default Credentials

- **Admin**: admin@cybersec.platform / admin123

## 💻 Development Setup

### Local Development without Docker

#### 1. Install Dependencies

```bash
# Frontend
cd frontend
npm install

# Auth Service
cd ../services/auth-service
npm install

# Terminal Service
cd ../terminal-service
npm install

# Course Service
cd ../course-service
pip install -r requirements.txt

# CTF Service
cd ../ctf-service
go mod download
```

#### 2. Start Services

```bash
# Terminal 1: PostgreSQL
docker run -d \
  --name cybersec-postgres \
  -e POSTGRES_DB=cybersec \
  -e POSTGRES_USER=cybersec \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:15-alpine

# Terminal 2: Redis
docker run -d \
  --name cybersec-redis \
  -p 6379:6379 \
  redis:7-alpine

# Terminal 3: Auth Service
cd services/auth-service
npm run dev

# Terminal 4: Terminal Service
cd ../terminal-service
npm run dev

# Terminal 5: Course Service
cd ../course-service
uvicorn main:app --reload --port 8003

# Terminal 6: CTF Service
cd ../ctf-service
go run main.go

# Terminal 7: Frontend
cd ../../frontend
npm start
```

#### 3. Initialize Database

```bash
psql -h localhost -U cybersec -d cybersec -f infrastructure/sql/init.sql
```

## 🚢 Deployment

### Production Deployment with Docker Swarm

#### 1. Prepare Production Environment

```bash
# Create production .env
cp .env.example .env.production
# Edit with production values

# Generate SSL certificates
mkdir -p docker/nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout docker/nginx/ssl/nginx.key \
  -out docker/nginx/ssl/nginx.crt
```

#### 2. Deploy to Swarm

```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml cybersecurity

# Check services
docker service ls
```

#### 3. Scale Services

```bash
# Scale frontend
docker service scale cybersecurity_frontend=3

# Scale API services
docker service scale cybersecurity_auth-service=2
docker service scale cybersecurity_course-service=2
```

### Kubernetes Deployment

Create Kubernetes manifests (see `k8s/` directory):

```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmaps.yaml
kubectl apply -f k8s/secrets.yaml
kubectl apply -f k8s/database.yaml
kubectl apply -f k8s/redis.yaml
kubectl apply -f k8s/services.yaml
kubectl apply -f k8s/deployments.yaml
kubectl apply -f k8s/ingress.yaml
```

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `JWT_SECRET` | JWT signing secret | CHANGE ME |
| `DATABASE_URL` | PostgreSQL connection string | postgresql://... |
| `REDIS_URL` | Redis connection string | redis://redis:6379 |
| `MAX_CONTAINERS_PER_USER` | Max Docker containers per user | 5 |
| `CONTAINER_TIMEOUT` | Container auto-stop timeout (seconds) | 3600 |

### Service Ports

| Service | Port |
|---------|------|
| Frontend | 3000 |
| Nginx Gateway | 80, 443 |
| Auth Service | 8001 |
| User Service | 8002 |
| Course Service | 8003 |
| CTF Service | 8004 |
| Terminal Service | 8005 |
| Progress Service | 8006 |
| PostgreSQL | 5432 |
| Redis | 6379 |
| RabbitMQ | 5672, 15672 |
| Grafana | 3001 |
| Kibana | 5601 |
| Prometheus | 9090 |

## 🔌 API Documentation

### Authentication Service

#### POST /api/auth/register
Register a new user.

**Request:**
```json
{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "SecurePass123!",
  "first_name": "John",
  "last_name": "Doe"
}
```

#### POST /api/auth/login
Authenticate user and receive tokens.

**Request:**
```json
{
  "email": "john@example.com",
  "password": "SecurePass123!"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "user": {
    "id": "uuid",
    "username": "johndoe",
    "email": "john@example.com",
    "role": "student"
  },
  "tokens": {
    "accessToken": "jwt-token",
    "refreshToken": "uuid",
    "expiresIn": 86400
  }
}
```

#### POST /api/auth/refresh
Refresh access token.

#### POST /api/auth/logout
Logout and invalidate tokens.

### Terminal Service

#### POST /api/terminal/containers
Create a new container.

**Request:**
```json
{
  "token": "jwt-token",
  "module_id": "uuid",
  "challenge_id": "uuid",
  "image": "ubuntu:latest",
  "port": 8080
}
```

**Response:**
```json
{
  "message": "Container created successfully",
  "sessionId": "uuid",
  "containerName": "cybersec_user_uuid12345678",
  "portMapping": {
    "internal": 8080,
    "external": 8081
  },
  "wsUrl": "ws://localhost/ws?token=xxx&session_id=xxx"
}
```

#### DELETE /api/terminal/containers/:sessionId
Stop a container.

#### WebSocket: /ws/terminal/
Connect to terminal via WebSocket.

### CTF Service

#### GET /api/ctf/challenges
List all CTF challenges.

**Query Parameters:**
- `category`: Filter by category
- `difficulty`: Filter by difficulty
- `published`: Show only published (default: true)

#### POST /api/ctf/submissions
Submit a flag.

**Request:**
```json
{
  "challenge_id": "uuid",
  "flag": "FLAG{example_flag}"
}
```

#### GET /api/ctf/leaderboard
Get global leaderboard.

### Course Service

#### GET /api/courses
List all courses.

#### GET /api/courses/:id
Get course details.

#### GET /api/courses/:id/modules
Get course modules.

## 🔒 Security Features

### Container Isolation
- Each user gets isolated containers
- Resource limits (CPU, memory, disk)
- Network isolation via custom networks
- Read-only filesystem where possible

### Network Security
- VPN-like isolated networks
- Firewall rules between services
- TLS/SSL encryption

### Access Control
- Role-Based Access Control (RBAC)
- JWT token validation
- Rate limiting per user/IP

### Monitoring & Auditing
- All actions logged
- Real-time monitoring
- Security alerts

## 📚 Offline Capabilities

### Content Caching
- Course content cached locally
- Video preloading
- Docker images cached

### Offline Mode
- Graceful degradation
- Queue for sync when online
- PWA capabilities

### Data Synchronization
- Conflict resolution
- Delta updates
- Background sync workers

## 🧪 Testing

```bash
# Frontend tests
cd frontend
npm test

# Backend service tests
cd services/auth-service
npm test

# Integration tests
docker-compose -f docker-compose.test.yml up --abort-on-container-exit
```

## 📊 Monitoring

- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3001 (admin/admin)
- **Kibana**: http://localhost:5601

## 🐛 Troubleshooting

### Container won't start
```bash
# Check logs
docker-compose logs terminal-service

# Check Docker socket permissions
sudo chmod 666 /var/run/docker.sock
```

### Database connection issues
```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check connection
docker-compose exec postgres psql -U cybersec -d cybersec
```

### WebSocket connection failures
```bash
# Check Nginx configuration
docker-compose logs nginx

# Verify WebSocket upgrade headers
curl -I -H "Connection: Upgrade" -H "Upgrade: websocket" http://localhost/ws
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- All contributors
- Open source community
- Cybersecurity educators worldwide

## 📞 Support

For support, email support@cybersec.platform or join our Discord server.

## 🗺️ Roadmap

- [ ] Mobile applications
- [ ] VR/AR labs
- [ ] AI-powered learning paths
- [ ] Advanced threat simulation
- [ ] Community marketplace
- [ ] Certification integration