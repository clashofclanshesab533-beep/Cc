#!/bin/bash

# CyberSec Learning Platform - Installation Script
# This script automates the setup and deployment of the platform

set -e

echo "🚀 CyberSec Learning Platform - Installation Script"
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Check if Docker is installed
check_docker() {
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        echo "Visit: https://docs.docker.com/get-docker/"
        exit 1
    fi
    print_success "Docker is installed"
}

# Check if Docker Compose is installed
check_docker_compose() {
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        print_error "Docker Compose is not installed. Please install Docker Compose first."
        echo "Visit: https://docs.docker.com/compose/install/"
        exit 1
    fi
    print_success "Docker Compose is installed"
}

# Check system requirements
check_requirements() {
    echo ""
    echo "📋 Checking system requirements..."
    
    # Check RAM
    TOTAL_RAM=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$TOTAL_RAM" -lt 8 ]; then
        print_warning "System has less than 8GB RAM. Platform may run slowly."
    else
        print_success "System has $TOTAL_RAM GB RAM"
    fi
    
    # Check disk space
    DISK_SPACE=$(df -BG . | awk 'NR==2 {print $4}' | sed 's/G//')
    if [ "$DISK_SPACE" -lt 50 ]; then
        print_warning "Less than 50GB disk space available. Platform may require more space."
    else
        print_success "System has $DISK_SPACE GB free disk space"
    fi
}

# Create .env file
create_env_file() {
    echo ""
    echo "⚙️  Creating environment configuration..."
    
    if [ ! -f .env ]; then
        cp .env.example .env
        
        # Generate secure JWT secret
        JWT_SECRET=$(openssl rand -hex 32)
        sed -i "s/your-super-secret-jwt-key-change-this-in-production/$JWT_SECRET/g" .env
        
        # Generate secure database password
        DB_PASSWORD=$(openssl rand -hex 16)
        sed -i "s/password/$DB_PASSWORD/g" .env
        
        # Update database URL with new password
        sed -i "s/postgresql:\/\/cybersec:password@/postgresql:\/\/cybersec:$DB_PASSWORD@/g" .env
        
        print_success "Environment file created with secure credentials"
        print_warning "Please save these credentials:"
        echo "  JWT Secret: $JWT_SECRET"
        echo "  Database Password: $DB_PASSWORD"
    else
        print_success "Environment file already exists"
    fi
}

# Build Docker images
build_images() {
    echo ""
    echo "🔨 Building Docker images (this may take a while)..."
    
    docker-compose build
    print_success "Docker images built successfully"
}

# Start services
start_services() {
    echo ""
    echo "▶️  Starting services..."
    
    docker-compose up -d
    print_success "Services started"
}

# Wait for services to be ready
wait_for_services() {
    echo ""
    echo "⏳ Waiting for services to be ready..."
    
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if docker-compose ps | grep -q "Exit"; then
            print_error "Some services failed to start. Check logs with: docker-compose logs"
            exit 1
        fi
        
        # Check if PostgreSQL is ready
        if docker-compose exec -T postgres pg_isready -U cybersec &> /dev/null; then
            print_success "PostgreSQL is ready"
            break
        fi
        
        echo "  Waiting... ($attempt/$max_attempts)"
        sleep 2
        ((attempt++))
    done
    
    if [ $attempt -gt $max_attempts ]; then
        print_error "Services failed to start within expected time"
        exit 1
    fi
}

# Initialize database
init_database() {
    echo ""
    echo "🗄️  Initializing database..."
    
    docker-compose exec -T postgres psql -U cybersec -d cybersec -f /docker-entrypoint-initdb.d/init.sql
    print_success "Database initialized"
}

# Display service status
show_status() {
    echo ""
    echo "📊 Service Status:"
    echo "=================="
    docker-compose ps
}

# Display access URLs
show_urls() {
    echo ""
    echo "🌐 Access URLs:"
    echo "==============="
    echo "Frontend:         http://localhost"
    echo "API Gateway:      http://localhost/api"
    echo ""
    echo "Monitoring:"
    echo "  Grafana:        http://localhost:3001 (admin/admin)"
    echo "  Prometheus:     http://localhost:9090"
    echo "  Kibana:         http://localhost:5601"
    echo ""
    echo "Message Queue:"
    echo "  RabbitMQ:       http://localhost:15672 (guest/guest)"
    echo ""
    echo "Default Credentials:"
    echo "  Admin:          admin@cybersec.platform / admin123"
    echo ""
}

# Main installation flow
main() {
    echo ""
    
    check_docker
    check_docker_compose
    check_requirements
    create_env_file
    
    read -p "Do you want to build Docker images now? (y/n) " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        build_images
        start_services
        wait_for_services
        init_database
        show_status
        show_urls
        
        print_success "Installation completed successfully!"
        echo ""
        echo "Next steps:"
        echo "1. Access the platform at http://localhost"
        echo "2. Login with admin credentials"
        echo "3. Change the admin password"
        echo "4. Create courses and challenges"
        echo ""
        echo "To view logs: docker-compose logs -f"
        echo "To stop services: docker-compose down"
    else
        print_warning "Installation skipped. Run 'docker-compose up -d' to start services later."
    fi
}

# Run main function
main