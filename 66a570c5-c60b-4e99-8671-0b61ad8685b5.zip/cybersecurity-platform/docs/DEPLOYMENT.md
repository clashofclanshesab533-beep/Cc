# Deployment Guide

This guide covers deploying the CyberSec Learning Platform to production environments.

## Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Docker Swarm Deployment](#docker-swarm-deployment)
3. [Kubernetes Deployment](#kubernetes-deployment)
4. [Cloud Platform Deployment](#cloud-platform-deployment)
5. [Security Hardening](#security-hardening)
6. [Monitoring & Logging](#monitoring--logging)
7. [Backup & Recovery](#backup--recovery)
8. [Performance Tuning](#performance-tuning)

## Pre-Deployment Checklist

### Security
- [ ] Change all default passwords
- [ ] Generate strong JWT secret
- [ ] Configure SSL/TLS certificates
- [ ] Set up firewall rules
- [ ] Configure rate limiting
- [ ] Enable audit logging
- [ ] Review and update RBAC settings

### Infrastructure
- [ ] Provision sufficient resources (CPU, RAM, storage)
- [ ] Configure backup strategy
- [ ] Set up monitoring and alerting
- [ ] Configure DNS records
- [ ] Set up CDN for static assets
- [ ] Configure load balancers

### Application
- [ ] Update environment variables
- [ ] Configure database connection pooling
- [ ] Set up Redis cluster (if needed)
- [ ] Configure message queue
- [ ] Set up external storage (S3, etc.)
- [ ] Configure email services

## Docker Swarm Deployment

### 1. Prepare Production Environment

```bash
# Clone repository
git clone https://github.com/your-org/cybersecurity-platform.git
cd cybersecurity-platform

# Create production environment file
cp .env.example .env.production

# Generate secure secrets
JWT_SECRET=$(openssl rand -hex 32)
DB_PASSWORD=$(openssl rand -hex 32)

# Update .env.production
sed -i "s/your-super-secret-jwt-key/$JWT_SECRET/g" .env.production
sed -i "s/password/$DB_PASSWORD/g" .env.production
```

### 2. Initialize Swarm

```bash
# Initialize swarm (on manager node)
docker swarm init --advertise-addr <MANAGER_IP>

# Join worker nodes (on worker nodes)
docker swarm join --token <WORKER_TOKEN> <MANAGER_IP>:2377
```

### 3. Create SSL Certificates

```bash
# Create certificate directory
mkdir -p docker/nginx/ssl

# Generate self-signed certificates (for testing)
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout docker/nginx/ssl/nginx.key \
  -out docker/nginx/ssl/nginx.crt \
  -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"

# OR use Let's Encrypt (for production)
# Install certbot
apt-get install certbot

# Generate certificates
certbot certonly --standalone -d yourdomain.com
cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem docker/nginx/ssl/nginx.crt
cp /etc/letsencrypt/live/yourdomain.com/privkey.pem docker/nginx/ssl/nginx.key
```

### 4. Deploy Stack

```bash
# Deploy with production configuration
docker stack deploy -c docker-compose.yml cybersecurity

# Deploy with environment file
docker stack deploy -c docker-compose.yml --env-file .env.production cybersecurity

# Check stack status
docker stack services cybersecurity

# Check stack logs
docker service logs cybersecurity_frontend -f
```

### 5. Scale Services

```bash
# Scale frontend for high availability
docker service scale cybersecurity_frontend=3

# Scale API services
docker service scale cybersecurity_auth-service=2
docker service scale cybersecurity_course-service=2
docker service scale cybersecurity_ctf-service=2
docker service scale cybersecurity_terminal-service=3

# Verify scaling
docker service ls
```

### 6. Configure Load Balancing

```bash
# Update service replicas
docker service update --replicas 3 cybersecurity_frontend

# Add placement constraints
docker service update \
  --constraint node.role==manager \
  cybersecurity_auth-service
```

## Kubernetes Deployment

### 1. Prepare Kubernetes Cluster

```bash
# Create namespace
kubectl create namespace cybersecurity

# Create config maps
kubectl create configmap cybersecurity-config \
  --from-env-file=.env.production \
  --namespace=cybersecurity

# Create secrets
kubectl create secret generic cybersecurity-secrets \
  --from-literal=jwt-secret=$JWT_SECRET \
  --from-literal=db-password=$DB_PASSWORD \
  --namespace=cybersecurity
```

### 2. Deploy Stateful Services

```bash
# Deploy PostgreSQL
kubectl apply -f k8s/postgres-statefulset.yaml

# Deploy Redis
kubectl apply -f k8s/redis-deployment.yaml

# Deploy RabbitMQ
kubectl apply -f k8s/rabbitmq-statefulset.yaml

# Verify deployments
kubectl get pods -n cybersecurity
```

### 3. Deploy Application Services

```bash
# Deploy microservices
kubectl apply -f k8s/auth-deployment.yaml
kubectl apply -f k8s/user-deployment.yaml
kubectl apply -f k8s/course-deployment.yaml
kubectl apply -f k8s/ctf-deployment.yaml
kubectl apply -f k8s/terminal-deployment.yaml
kubectl apply -f k8s/progress-deployment.yaml

# Deploy frontend
kubectl apply -f k8s/frontend-deployment.yaml

# Verify all pods are running
kubectl get pods -n cybersecurity -w
```

### 4. Expose Services

```bash
# Create services
kubectl apply -f k8s/services.yaml

# Create ingress
kubectl apply -f k8s/ingress.yaml

# Verify ingress
kubectl get ingress -n cybersecurity
```

### 5. Configure Horizontal Pod Autoscaling

```bash
# Create HPA for frontend
kubectl autoscale deployment frontend \
  --namespace=cybersecurity \
  --cpu-percent=70 \
  --min=2 \
  --max=10

# Create HPA for API services
kubectl autoscale deployment auth-service \
  --namespace=cybersecurity \
  --cpu-percent=70 \
  --min=2 \
  --max=5

# Check HPA status
kubectl get hpa -n cybersecurity
```

### 6. Deploy Monitoring Stack

```bash
# Deploy Prometheus
kubectl apply -f k8s/monitoring/prometheus.yaml

# Deploy Grafana
kubectl apply -f k8s/monitoring/grafana.yaml

# Create dashboards
kubectl apply -f k8s/monitoring/dashboards/
```

## Cloud Platform Deployment

### AWS Deployment

#### 1. Using ECS

```bash
# Create ECR repository
aws ecr create-repository --repository-name cybersecurity-platform

# Login to ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# Build and push images
docker build -t cybersecurity-platform/frontend ./frontend
docker tag cybersecurity-platform/frontend:latest \
  <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/cybersecurity-platform/frontend:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/cybersecurity-platform/frontend:latest

# Create ECS task definition
aws ecs register-task-definition --cli-input-json file://ecs-task-definition.json

# Create ECS service
aws ecs create-service \
  --cluster cybersecurity-cluster \
  --service-name frontend \
  --task-definition cybersecurity-platform:1 \
  --desired-count 3
```

#### 2. Using EKS

```bash
# Create EKS cluster
eksctl create cluster \
  --name cybersecurity \
  --region us-east-1 \
  --nodes 3 \
  --node-type t3.xlarge

# Deploy using Kubernetes manifests (see above)
kubectl apply -f k8s/ --namespace=cybersecurity
```

### GCP Deployment

#### Using GKE

```bash
# Create GKE cluster
gcloud container clusters create cybersecurity \
  --num-nodes=3 \
  --machine-type=e2-highcpu-4 \
  --zone=us-central1-a

# Get credentials
gcloud container clusters get-credentials cybersecurity \
  --zone=us-central1-a

# Deploy using Kubernetes manifests
kubectl apply -f k8s/ --namespace=cybersecurity
```

### Azure Deployment

#### Using AKS

```bash
# Create resource group
az group create --name cybersecurity-rg --location eastus

# Create AKS cluster
az aks create \
  --resource-group cybersecurity-rg \
  --name cybersecurity-cluster \
  --node-count 3 \
  --node-vm-size Standard_D4s_v3

# Get credentials
az aks get-credentials \
  --resource-group cybersecurity-rg \
  --name cybersecurity-cluster

# Deploy using Kubernetes manifests
kubectl apply -f k8s/ --namespace=cybersecurity
```

## Security Hardening

### 1. Network Security

```bash
# Configure firewall rules (UFW)
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable

# Configure iptables for service isolation
iptables -A INPUT -i docker0 -j DROP
iptables -A FORWARD -i docker0 -o docker0 -j ACCEPT
```

### 2. Container Security

```bash
# Run containers with non-root user
# Add to Dockerfile:
USER node

# Use read-only filesystem
docker run --read-only --tmpfs /tmp ubuntu

# Limit container capabilities
docker run --cap-drop=ALL --cap-add=NET_BIND_SERVICE ubuntu

# Set security options
docker run --security-opt=no-new-privileges ubuntu
```

### 3. Application Security

```bash
# Update production .env with security settings
JWT_SECRET=<generate-256-bit-secret>
ENABLE_HTTPS=true
CORS_ORIGIN=https://yourdomain.com
RATE_LIMIT_ENABLED=true
RATE_LIMIT_MAX=100
RATE_LIMIT_WINDOW=900000
```

### 4. Database Security

```sql
-- Create limited user for application
CREATE USER cybersec_app WITH PASSWORD 'secure_password';

-- Grant necessary permissions only
GRANT CONNECT ON DATABASE cybersec TO cybersec_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO cybersec_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO cybersec_app;

-- Enable SSL connections
ALTER DATABASE cybersec SET ssl = on;
```

## Monitoring & Logging

### 1. Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'cybersecurity-platform'
    static_configs:
      - targets: ['auth-service:8000', 'course-service:8000', 'ctf-service:8000']
```

### 2. Grafana Dashboards

- Import dashboards from `k8s/monitoring/dashboards/`
- Configure alerting rules
- Set up notification channels (email, Slack, PagerDuty)

### 3. ELK Stack

```bash
# Configure Filebeat on application servers
filebeat.inputs:
  - type: docker
    containers.ids: '*'
    paths:
      - '/var/lib/docker/containers/*/*.log'

# Configure Logstash pipeline
input {
  beats {
    port => 5044
  }
}

filter {
  if [docker][container][image] =~ /cybersecurity/ {
    grok {
      match => { "message" => "%{TIMESTAMP_ISO8601:timestamp} %{LOGLEVEL:level} %{GREEDYDATA:msg}" }
    }
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "cybersecurity-%{+YYYY.MM.dd}"
  }
}
```

## Backup & Recovery

### 1. Database Backup

```bash
# Create backup script
cat > /usr/local/bin/backup-db.sh <<'EOF'
#!/bin/bash
BACKUP_DIR="/backups/postgres"
DATE=$(date +%Y%m%d_%H%M%S)
docker exec postgres pg_dump -U cybersec cybersec > $BACKUP_DIR/backup_$DATE.sql
gzip $BACKUP_DIR/backup_$DATE.sql
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +7 -delete
EOF

chmod +x /usr/local/bin/backup-db.sh

# Add to crontab
crontab -e
# 0 2 * * * /usr/local/bin/backup-db.sh
```

### 2. Volume Backup

```bash
# Backup Docker volumes
docker run --rm \
  -v cybersecurity_postgres-data:/data \
  -v /backups:/backup \
  alpine tar czf /backup/postgres-data-$(date +%Y%m%d).tar.gz -C /data .
```

### 3. Disaster Recovery

```bash
# Restore database
gunzip < backup_20231201_020000.sql.gz | \
  docker exec -i postgres psql -U cybersec cybersec

# Restore volumes
docker run --rm \
  -v cybersecurity_postgres-data:/data \
  -v /backups:/backup \
  alpine tar xzf /backup/postgres-data-20231201.tar.gz -C /data
```

## Performance Tuning

### 1. Database Optimization

```sql
-- Update PostgreSQL configuration
ALTER SYSTEM SET shared_buffers = '4GB';
ALTER SYSTEM SET effective_cache_size = '12GB';
ALTER SYSTEM SET maintenance_work_mem = '1GB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;

-- Create indexes for frequently queried columns
CREATE INDEX CONCURRENTLY idx_user_progress_user_module 
  ON user_progress(user_id, module_id);
```

### 2. Redis Configuration

```conf
# redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
```

### 3. Application Tuning

```bash
# Increase Node.js memory limit
NODE_OPTIONS=--max-old-space-size=4096

# Configure connection pooling
PGPOOL_SIZE=20
PGPOOL_MAX=50
REDIS_POOL_SIZE=10

# Enable compression
ENABLE_GZIP=true
COMPRESSION_LEVEL=6
```

### 4. Container Resource Limits

```yaml
# docker-compose.yml
services:
  frontend:
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M
```

## Post-Deployment Verification

```bash
# Health check
curl http://yourdomain.com/health

# Check all services
docker-compose ps
# or
kubectl get pods -n cybersecurity

# Check logs
docker-compose logs -f
# or
kubectl logs -f deployment/frontend -n cybersecurity

# Monitor metrics
curl http://yourdomain.com:9090/api/v1/query?query=up

# Test authentication
curl -X POST http://yourdomain.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@cybersec.platform","password":"admin123"}'
```

## Troubleshooting

### Common Issues

1. **Containers failing to start**
   ```bash
   docker-compose logs <service-name>
   kubectl describe pod <pod-name> -n cybersecurity
   ```

2. **Database connection errors**
   ```bash
   docker-compose exec postgres psql -U cybersec -d cybersec
   ```

3. **High memory usage**
   ```bash
   docker stats
   kubectl top pods -n cybersecurity
   ```

4. **WebSocket connection failures**
   ```bash
   # Check Nginx configuration
   docker-compose exec nginx nginx -t
   
   # Verify WebSocket upgrade
   curl -I -H "Connection: Upgrade" \
     -H "Upgrade: websocket" \
     http://yourdomain.com/ws
   ```

## Support

For deployment issues, contact:
- Email: support@cybersec.platform
- Documentation: https://docs.cybersec.platform
- Issues: https://github.com/your-org/cybersecurity-platform/issues