# CyberSec Learning Platform - Architecture

## System Overview
A microservices-based cybersecurity training platform providing hands-on terminal access and CTF challenges.

## Tech Stack

### Frontend
- **Framework**: React 18+ with TypeScript
- **UI Library**: Material-UI / TailwindCSS
- **Terminal**: xterm.js
- **State Management**: Redux Toolkit
- **Real-time**: Socket.IO Client
- **Offline Support**: Service Workers + IndexedDB

### Backend Services
- **API Gateway**: Nginx
- **Authentication Service**: Node.js + Express + JWT
- **User Service**: Python + FastAPI
- **Course Service**: Python + FastAPI
- **CTF Service**: Go + Gin
- **Terminal Service**: Node.js + WebSocket + Docker API
- **Progress Service**: Python + FastAPI

### Infrastructure
- **Container Orchestration**: Docker Compose (development) / Kubernetes (production)
- **Databases**:
  - PostgreSQL (relational data)
  - Redis (caching, sessions)
  - MongoDB (logs, unstructured data)
- **Message Queue**: RabbitMQ
- **Monitoring**: Prometheus + Grafana
- **Logging**: ELK Stack (Elasticsearch, Logstash, Kibana)

### Security
- **Container Isolation**: Docker seccomp, AppArmor
- **Network**: Custom bridge networks, iptables rules
- **Authentication**: JWT + Refresh Tokens
- **Authorization**: Role-Based Access Control (RBAC)
- **Encryption**: TLS/SSL for all communications

## Microservices Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (React)                      │
└─────────────────────┬───────────────────────────────────────┘
                      │ HTTPS/WSS
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                      Nginx API Gateway                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Auth       │ │   User   │ │   Course     │
│  Service     │ │ Service  │ │   Service    │
└──────────────┘ └──────────┘ └──────────────┘
        │             │             │
        └─────────────┼─────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Terminal   │ │   CTF    │ │   Progress   │
│  Service     │ │ Service  │ │   Service    │
└──────────────┘ └──────────┘ └──────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐
│   Docker     │ │PostgreSQL│ │   Redis      │
│   Daemon     │ │          │ │              │
└──────────────┘ └──────────┘ └──────────────┘
```

## Service Responsibilities

### Authentication Service
- User registration and login
- JWT token generation and validation
- Refresh token management
- Password reset flows
- 2FA implementation

### User Service
- User profile management
- Role and permission management
- User preferences
- Activity tracking

### Course Service
- Course content management
- Module and lesson organization
- Prerequisite validation
- Content versioning

### CTF Service
- Challenge management
- Flag validation
- Scoring system
- Leaderboard
- Team management

### Terminal Service
- Container lifecycle management
- WebSocket terminal connections
- Resource allocation
- Container security policies

### Progress Service
- Learning progress tracking
- Assessment scoring
- Certificate generation
- Learning analytics

## Data Models

### User
- id, username, email, password_hash
- role (student, instructor, admin)
- profile_data, preferences
- created_at, updated_at

### Course
- id, title, description, difficulty
- category, prerequisites
- estimated_duration, tags

### Module
- id, course_id, title, order
- content, type (video, lab, quiz)

### CTF Challenge
- id, title, description, category
- difficulty, points, flag
- docker_image, resources

### Progress
- user_id, course_id, module_id
- status, score, completed_at

## Security Features

1. **Container Isolation**
   - Each user gets isolated containers
   - Resource limits (CPU, memory, disk)
   - Network isolation via custom networks
   - Read-only filesystem where possible

2. **Network Security**
   - VPN-like isolated networks
   - Firewall rules between services
   - Traffic encryption (TLS)

3. **Access Control**
   - RBAC for all endpoints
   - JWT token validation
   - Rate limiting per user/IP

4. **Monitoring & Auditing**
   - All actions logged
   - Real-time monitoring
   - Security alerts

## Offline Capabilities

1. **Content Caching**
   - Course content cached locally
   - Video preloading
   - Docker images cached

2. **Offline Mode**
   - Graceful degradation
   - Queue for sync when online
   - PWA capabilities

3. **Data Synchronization**
   - Conflict resolution
   - Delta updates
   - Background sync workers