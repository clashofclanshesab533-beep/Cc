import React from 'react';
import { Container, Typography, Box } from '@mui/material';

const CourseView = () => (
  <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
    <Typography variant="h4" gutterBottom sx={{ color: '#00ff88', mb: 4 }}>
      Course View
    </Typography>
    <Box sx={{ p: 4, bgcolor: '#1a1f3a', borderRadius: 2, textAlign: 'center' }}>
      <Typography variant="h6" sx={{ color: '#a0aec0' }}>
        Course content coming soon!
      </Typography>
    </Box>
  </Container>
);

export default CourseView;