import React, { useEffect, useState } from 'react';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
  CardMedia,
  Chip,
  LinearProgress,
  Button,
} from '@mui/material';
import {
  School,
  Flag,
  Terminal as TerminalIcon,
  TrendingUp,
  Assessment,
  EmojiEvents,
  Lock,
  PlayArrow,
} from '@mui/icons-material';
import axios from 'axios';

const Dashboard = () => {
  const [userProgress, setUserProgress] = useState([]);
  const [recentCourses, setRecentCourses] = useState([]);
  const [ctfStats, setCTFStats] = useState({ solved: 0, points: 0, rank: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const token = localStorage.getItem('access_token');
      
      // Fetch user progress
      const progressRes = await axios.get('http://localhost/api/progress/user', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUserProgress(progressRes.data.progress || []);

      // Fetch courses
      const coursesRes = await axios.get('http://localhost/api/courses', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecentCourses(coursesRes.data.courses?.slice(0, 4) || []);

      // Fetch CTF stats
      try {
        const ctfRes = await axios.get('http://localhost/api/ctf/submissions/user', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const solvedChallenges = ctfRes.data.submissions?.filter(s => s.is_correct) || [];
        setCTFStats({
          solved: solvedChallenges.length,
          points: solvedChallenges.reduce((acc, curr) => acc + (curr.points || 0), 0),
          rank: Math.floor(Math.random() * 100) // Mock rank for demo
        });
      } catch (err) {
        console.log('CTF stats not available');
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner': return '#00ff88';
      case 'intermediate': return '#f59e0b';
      case 'advanced': return '#ef4444';
      case 'expert': return '#7c3aed';
      default: return '#6b7280';
    }
  };

  const getProgressColor = (percentage) => {
    if (percentage >= 75) return '#00ff88';
    if (percentage >= 50) return '#f59e0b';
    if (percentage >= 25) return '#ef4444';
    return '#6b7280';
  };

  const StatCard = ({ title, value, icon, color }) => (
    <Paper
      elevation={2}
      sx={{
        p: 3,
        height: '100%',
        background: 'linear-gradient(135deg, #1a1f3a 0%, #0f142b 100%)',
        borderLeft: `4px solid ${color}`,
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="body2" sx={{ color: '#a0aec0', mb: 1 }}>
            {title}
          </Typography>
          <Typography variant="h4" sx={{ color: '#ffffff', fontWeight: 'bold' }}>
            {value}
          </Typography>
        </Box>
        <Box
          sx={{
            width: 56,
            height: 56,
            borderRadius: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: `${color}20`,
          }}
        >
          {React.createElement(icon, { sx: { fontSize: 32, color } })}
        </Box>
      </Box>
    </Paper>
  );

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ color: '#00ff88', mb: 4 }}>
        Welcome Back, Student! 🎓
      </Typography>

      {/* Stats Grid */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Courses Enrolled"
            value={userProgress.length}
            icon={School}
            color="#00ff88"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="CTF Challenges Solved"
            value={ctfStats.solved}
            icon={Flag}
            color="#7c3aed"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Points"
            value={ctfStats.points}
            icon={EmojiEvents}
            color="#f59e0b"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Global Rank"
            value={`#${ctfStats.rank}`}
            icon={TrendingUp}
            color="#ef4444"
          />
        </Grid>
      </Grid>

      {/* Main Content Grid */}
      <Grid container spacing={3}>
        {/* Recent Courses */}
        <Grid item xs={12} lg={8}>
          <Paper elevation={2} sx={{ p: 3, background: '#1a1f3a' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6" sx={{ color: '#ffffff' }}>
                Continue Learning
              </Typography>
              <Button
                variant="outlined"
                size="small"
                sx={{ color: '#00ff88', borderColor: '#00ff88' }}
                onClick={() => window.location.href = '/courses'}
              >
                View All Courses
              </Button>
            </Box>

            <Grid container spacing={2}>
              {recentCourses.map((course) => {
                const progress = userProgress.find(p => p.course_id === course.id);
                const percentage = progress?.percentage || 0;
                
                return (
                  <Grid item xs={12} md={6} key={course.id}>
                    <Card
                      sx={{
                        background: '#0f142b',
                        border: '1px solid #4a5568',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: '0 8px 24px rgba(0, 255, 136, 0.15)',
                        },
                      }}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 2 }}>
                          <Box
                            sx={{
                              width: 48,
                              height: 48,
                              borderRadius: 2,
                              bgcolor: '#00ff8820',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              mr: 2,
                            }}
                          >
                            <School sx={{ color: '#00ff88', fontSize: 28 }} />
                          </Box>
                          <Box sx={{ flex: 1 }}>
                            <Typography variant="h6" sx={{ color: '#ffffff', mb: 0.5 }}>
                              {course.title}
                            </Typography>
                            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                              <Chip
                                label={course.difficulty || 'Beginner'}
                                size="small"
                                sx={{
                                  bgcolor: `${getDifficultyColor(course.difficulty)}20`,
                                  color: getDifficultyColor(course.difficulty),
                                  fontSize: 12,
                                }}
                              />
                              <Chip
                                label={course.category || 'General'}
                                size="small"
                                sx={{
                                  bgcolor: '#4a5568',
                                  color: '#a0aec0',
                                  fontSize: 12,
                                }}
                              />
                            </Box>
                          </Box>
                        </Box>

                        {progress && (
                          <Box>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                              <Typography variant="body2" sx={{ color: '#a0aec0' }}>
                                Progress
                              </Typography>
                              <Typography variant="body2" sx={{ color: '#00ff88' }}>
                                {percentage}%
                              </Typography>
                            </Box>
                            <LinearProgress
                              variant="determinate"
                              value={percentage}
                              sx={{
                                height: 8,
                                borderRadius: 4,
                                bgcolor: '#1a1f3a',
                                '& .MuiLinearProgress-bar': {
                                  bgcolor: getProgressColor(percentage),
                                  borderRadius: 4,
                                },
                              }}
                            />
                          </Box>
                        )}

                        <Button
                          fullWidth
                          variant="contained"
                          startIcon={<PlayArrow />}
                          sx={{
                            mt: 2,
                            bgcolor: '#00ff88',
                            color: '#000',
                            '&:hover': { bgcolor: '#00cc6a' },
                          }}
                          onClick={() => window.location.href = `/courses/${course.id}`}
                        >
                          {percentage > 0 ? 'Continue' : 'Start Learning'}
                        </Button>
                      </CardContent>
                    </Card>
                  </Grid>
                );
              })}
            </Grid>
          </Paper>
        </Grid>

        {/* Quick Actions & Activity */}
        <Grid item xs={12} lg={4}>
          {/* Quick Actions */}
          <Paper elevation={2} sx={{ p: 3, background: '#1a1f3a', mb: 3 }}>
            <Typography variant="h6" sx={{ color: '#ffffff', mb: 3 }}>
              Quick Actions
            </Typography>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<TerminalIcon />}
                sx={{
                  justifyContent: 'flex-start',
                  color: '#00ff88',
                  borderColor: '#4a5568',
                  py: 2,
                  '&:hover': {
                    borderColor: '#00ff88',
                    bgcolor: '#00ff8810',
                  },
                }}
                onClick={() => window.location.href = '/terminal'}
              >
                Open Terminal
              </Button>

              <Button
                fullWidth
                variant="outlined"
                startIcon={<Flag />}
                sx={{
                  justifyContent: 'flex-start',
                  color: '#7c3aed',
                  borderColor: '#4a5568',
                  py: 2,
                  '&:hover': {
                    borderColor: '#7c3aed',
                    bgcolor: '#7c3aed20',
                  },
                }}
                onClick={() => window.location.href = '/ctf'}
              >
                CTF Challenges
              </Button>

              <Button
                fullWidth
                variant="outlined"
                startIcon={<Assessment />}
                sx={{
                  justifyContent: 'flex-start',
                  color: '#f59e0b',
                  borderColor: '#4a5568',
                  py: 2,
                  '&:hover': {
                    borderColor: '#f59e0b',
                    bgcolor: '#f59e0b20',
                  },
                }}
                onClick={() => window.location.href = '/leaderboard'}
              >
                Leaderboard
              </Button>

              <Button
                fullWidth
                variant="outlined"
                startIcon={<EmojiEvents />}
                sx={{
                  justifyContent: 'flex-start',
                  color: '#ef4444',
                  borderColor: '#4a5568',
                  py: 2,
                  '&:hover': {
                    borderColor: '#ef4444',
                    bgcolor: '#ef444420',
                  },
                }}
                onClick={() => window.location.href = '/profile'}
              >
                My Achievements
              </Button>
            </Box>
          </Paper>

          {/* Recent Activity */}
          <Paper elevation={2} sx={{ p: 3, background: '#1a1f3a' }}>
            <Typography variant="h6" sx={{ color: '#ffffff', mb: 3 }}>
              Recent Activity
            </Typography>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    bgcolor: '#00ff8820',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <School sx={{ color: '#00ff88', fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography variant="body2" sx={{ color: '#ffffff' }}>
                    Completed "Linux Basics"
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#a0aec0' }}>
                    2 hours ago
                  </Typography>
                </Box>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    bgcolor: '#7c3aed20',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Flag sx={{ color: '#7c3aed', fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography variant="body2" sx={{ color: '#ffffff' }}>
                    Solved "Web Challenge 1"
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#a0aec0' }}>
                    5 hours ago
                  </Typography>
                </Box>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    bgcolor: '#f59e0b20',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <TerminalIcon sx={{ color: '#f59e0b', fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography variant="body2" sx={{ color: '#ffffff' }}>
                    Started "Pentesting Lab"
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#a0aec0' }}>
                    1 day ago
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;