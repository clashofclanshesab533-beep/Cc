import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import { Flag } from '@mui/icons-material';

const CTF = () => (
  <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
    <Typography variant="h4" gutterBottom sx={{ color: '#7c3aed', mb: 4 }}>
      <Flag sx={{ mr: 1, verticalAlign: 'middle' }} />
      CTF Challenges
    </Typography>
    <Box sx={{ p: 4, bgcolor: '#1a1f3a', borderRadius: 2, textAlign: 'center' }}>
      <Typography variant="h6" sx={{ color: '#a0aec0' }}>
        CTF challenges coming soon!
      </Typography>
    </Box>
  </Container>
);

export default CTF;