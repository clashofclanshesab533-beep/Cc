import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import { Person } from '@mui/icons-material';

const Profile = () => (
  <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
    <Typography variant="h4" gutterBottom sx={{ color: '#00ff88', mb: 4 }}>
      <Person sx={{ mr: 1, verticalAlign: 'middle' }} />
      Profile
    </Typography>
    <Box sx={{ p: 4, bgcolor: '#1a1f3a', borderRadius: 2, textAlign: 'center' }}>
      <Typography variant="h6" sx={{ color: '#a0aec0' }}>
        Profile page coming soon!
      </Typography>
    </Box>
  </Container>
);

export default Profile;