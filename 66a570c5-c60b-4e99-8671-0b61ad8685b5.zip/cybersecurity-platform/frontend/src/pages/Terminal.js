import React, { useEffect, useRef, useState } from 'react';
import { Container, Box, Button, TextField, Select, MenuItem, Typography } from '@mui/material';
import { PlayArrow, Stop, Refresh } from '@mui/icons-material';
import { Terminal as XTerm } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';
import axios from 'axios';

const Terminal = () => {
  const terminalRef = useRef(null);
  const xtermRef = useRef(null);
  const fitAddonRef = useRef(null);
  const [sessionId, setSessionId] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [dockerImage, setDockerImage] = useState('ubuntu:latest');
  const [containerPort, setContainerPort] = useState('');
  const [loading, setLoading] = useState(false);
  const [ws, setWs] = useState(null);

  useEffect(() => {
    if (terminalRef.current && !xtermRef.current) {
      // Initialize xterm
      xtermRef.current = new XTerm({
        theme: {
          background: '#000000',
          foreground: '#00ff88',
          cursor: '#00ff88',
          cursorAccent: '#000000',
          selection: 'rgba(0, 255, 136, 0.3)',
        },
        fontSize: 14,
        fontFamily: 'monospace',
        cursorBlink: true,
        cursorStyle: 'block',
        scrollback: 1000,
        tabStopWidth: 4,
      });

      // Add fit addon
      fitAddonRef.current = new FitAddon();
      xtermRef.current.loadAddon(fitAddonRef.current);

      // Mount to DOM
      xtermRef.current.open(terminalRef.current);
      fitAddonRef.current.fit();

      // Handle window resize
      const handleResize = () => {
        if (fitAddonRef.current) {
          fitAddonRef.current.fit();
        }
      };

      window.addEventListener('resize', handleResize);

      return () => {
        window.removeEventListener('resize', handleResize);
        if (xtermRef.current) {
          xtermRef.current.dispose();
          xtermRef.current = null;
        }
      };
    }
  }, []);

  const startContainer = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      
      const response = await axios.post(
        'http://localhost/api/terminal/containers',
        {
          token,
          image: dockerImage,
          port: containerPort ? parseInt(containerPort) : null,
        }
      );

      const { sessionId: newSessionId, wsUrl } = response.data;
      setSessionId(newSessionId);

      // Connect WebSocket
      connectWebSocket(wsUrl, token, newSessionId);
    } catch (error) {
      console.error('Failed to start container:', error);
      alert('Failed to start container. Please check the image and try again.');
    } finally {
      setLoading(false);
    }
  };

  const connectWebSocket = (wsUrl, token, sid) => {
    const websocket = new WebSocket(wsUrl);

    websocket.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
    };

    websocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'output') {
          xtermRef.current.write(data.output);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      xtermRef.current.write('\r\n\x1b[31mConnection error\x1b[0m\r\n');
    };

    websocket.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      xtermRef.current.write('\r\n\x1b[33mConnection closed\x1b[0m\r\n');
    };

    setWs(websocket);

    // Handle terminal input
    xtermRef.current.onData((data) => {
      if (websocket.readyState === WebSocket.OPEN) {
        websocket.send(JSON.stringify({ type: 'input', input: data }));
      }
    });

    // Handle terminal resize
    xtermRef.current.onResize(({ cols, rows }) => {
      if (websocket.readyState === WebSocket.OPEN) {
        websocket.send(JSON.stringify({ type: 'resize', cols, rows }));
      }
    });
  };

  const stopContainer = async () => {
    if (!sessionId) return;

    try {
      const token = localStorage.getItem('access_token');
      await axios.delete(`http://localhost/api/terminal/containers/${sessionId}`, {
        data: { token }
      });

      // Close WebSocket
      if (ws) {
        ws.close();
        setWs(null);
      }

      setSessionId(null);
      setIsConnected(false);
      xtermRef.current.clear();
    } catch (error) {
      console.error('Failed to stop container:', error);
    }
  };

  const clearTerminal = () => {
    xtermRef.current.clear();
  };

  const predefinedImages = [
    { value: 'ubuntu:latest', label: 'Ubuntu Latest' },
    { value: 'ubuntu:20.04', label: 'Ubuntu 20.04' },
    { value: 'alpine:latest', label: 'Alpine Linux' },
    { value: 'debian:bullseye', label: 'Debian Bullseye' },
    { value: 'kali:latest', label: 'Kali Linux' },
    { value: 'cybersec/web-challenge:latest', label: 'Web Challenge' },
    { value: 'cybersec/crypto-challenge:latest', label: 'Crypto Challenge' },
    { value: 'cybersec/forensics:latest', label: 'Forensics Lab' },
    { value: 'cybersec/pentest:latest', label: 'Penetration Testing' },
  ];

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ color: '#00ff88' }}>
        <Refresh sx={{ mr: 1, verticalAlign: 'middle' }} />
        Terminal Access
      </Typography>

      <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Select
          value={dockerImage}
          onChange={(e) => setDockerImage(e.target.value)}
          sx={{ minWidth: 200, bgcolor: '#1a1f3a', color: 'white' }}
          disabled={isConnected}
        >
          {predefinedImages.map((image) => (
            <MenuItem key={image.value} value={image.value}>
              {image.label}
            </MenuItem>
          ))}
        </Select>

        <TextField
          placeholder="Port (optional)"
          value={containerPort}
          onChange={(e) => setContainerPort(e.target.value)}
          sx={{ 
            bgcolor: '#1a1f3a',
            '& .MuiInputBase-input': { color: 'white' }
          }}
          disabled={isConnected}
        />

        <Button
          variant="contained"
          startIcon={<PlayArrow />}
          onClick={startContainer}
          disabled={isConnected || loading}
          sx={{ bgcolor: '#00ff88', color: '#000', '&:hover': { bgcolor: '#00cc6a' } }}
        >
          {loading ? 'Starting...' : 'Start Container'}
        </Button>

        <Button
          variant="contained"
          startIcon={<Stop />}
          onClick={stopContainer}
          disabled={!isConnected}
          sx={{ bgcolor: '#ef4444', color: 'white', '&:hover': { bgcolor: '#dc2626' } }}
        >
          Stop Container
        </Button>

        <Button
          variant="outlined"
          onClick={clearTerminal}
          sx={{ color: '#00ff88', borderColor: '#00ff88' }}
        >
          Clear
        </Button>
      </Box>

      <Box
        sx={{
          bgcolor: '#000000',
          borderRadius: 2,
          overflow: 'hidden',
          border: '1px solid #4a5568',
          height: '70vh',
        }}
      >
        <Box
          sx={{
            bgcolor: '#1a1f3a',
            px: 2,
            py: 1,
            borderBottom: '1px solid #4a5568',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Typography variant="body2" sx={{ color: '#a0aec0' }}>
            {isConnected ? (
              <>
                <span style={{ color: '#00ff88' }}>●</span> Connected - {sessionId?.substring(0, 8)}
              </>
            ) : (
              <>
                <span style={{ color: '#f59e0b' }}>●</span> Disconnected
              </>
            )}
          </Typography>
          <Typography variant="body2" sx={{ color: '#a0aec0' }}>
            {dockerImage}
          </Typography>
        </Box>

        <Box
          ref={terminalRef}
          sx={{
            height: 'calc(100% - 48px)',
            padding: '10px',
          }}
        />
      </Box>

      <Box sx={{ mt: 3, p: 2, bgcolor: '#1a1f3a', borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom sx={{ color: '#00ff88' }}>
          Quick Commands
        </Typography>
        <Typography variant="body2" sx={{ color: '#a0aec0', fontFamily: 'monospace' }}>
          ls -la                    List all files<br />
          pwd                       Print working directory<br />
          cat &lt;file&gt;              Display file contents<br />
          nano &lt;file&gt;             Edit file<br />
          find / -name "*.txt"      Search for files<br />
          grep -r "text" /          Search for text<br />
          chmod +x &lt;file&gt;          Make file executable<br />
          ./&lt;file&gt;                 Execute file<br />
          history                   Show command history
        </Typography>
      </Box>
    </Container>
  );
};

export default Terminal;