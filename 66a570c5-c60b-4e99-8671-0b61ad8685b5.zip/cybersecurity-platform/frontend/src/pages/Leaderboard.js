import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import { EmojiEvents } from '@mui/icons-material';

const Leaderboard = () => (
  <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
    <Typography variant="h4" gutterBottom sx={{ color: '#f59e0b', mb: 4 }}>
      <EmojiEvents sx={{ mr: 1, verticalAlign: 'middle' }} />
      Leaderboard
    </Typography>
    <Box sx={{ p: 4, bgcolor: '#1a1f3a', borderRadius: 2, textAlign: 'center' }}>
      <Typography variant="h6" sx={{ color: '#a0aec0' }}>
        Leaderboard coming soon!
      </Typography>
    </Box>
  </Container>
);

export default Leaderboard;