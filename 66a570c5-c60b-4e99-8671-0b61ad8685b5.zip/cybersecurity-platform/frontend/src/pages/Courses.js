import React, { useState, useEffect } from 'react';
import { Container, Grid, Typography, Box, TextField } from '@mui/material';
import { Search, Filter } from '@mui/icons-material';
import axios from 'axios';

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    filterCourses();
  }, [searchTerm, courses]);

  const fetchCourses = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get('http://localhost/api/courses', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCourses(response.data.courses || []);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterCourses = () => {
    const filtered = courses.filter(course =>
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredCourses(filtered);
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner': return '#00ff88';
      case 'intermediate': return '#f59e0b';
      case 'advanced': return '#ef4444';
      case 'expert': return '#7c3aed';
      default: return '#6b7280';
    }
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ color: '#00ff88', mb: 4 }}>
        Courses
      </Typography>

      <TextField
        fullWidth
        placeholder="Search courses..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        InputProps={{
          startAdornment: <Search sx={{ mr: 1, color: '#a0aec0' }} />,
        }}
        sx={{
          mb: 4,
          '& .MuiInputBase-root': { color: '#ffffff' },
          '& .MuiOutlinedInput-root': {
            '& fieldset': { borderColor: '#4a5568' },
            '&:hover fieldset': { borderColor: '#00ff88' },
          },
        }}
      />

      <Grid container spacing={3}>
        {filteredCourses.map((course) => (
          <Grid item xs={12} md={6} lg={4} key={course.id}>
            <Box
              onClick={() => window.location.href = `/courses/${course.id}`}
              sx={{
                p: 3,
                bgcolor: '#1a1f3a',
                border: '1px solid #4a5568',
                borderRadius: 2,
                cursor: 'pointer',
                transition: 'all 0.3s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  borderColor: '#00ff88',
                  boxShadow: '0 8px 24px rgba(0, 255, 136, 0.15)',
                },
              }}
            >
              <Typography variant="h6" sx={{ color: '#ffffff', mb: 1 }}>
                {course.title}
              </Typography>
              <Typography variant="body2" sx={{ color: '#a0aec0', mb: 2 }}>
                {course.description || 'No description available'}
              </Typography>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Box
                  sx={{
                    px: 2,
                    py: 0.5,
                    borderRadius: 1,
                    bgcolor: `${getDifficultyColor(course.difficulty)}20`,
                    color: getDifficultyColor(course.difficulty),
                    fontSize: 12,
                    fontWeight: 'bold',
                  }}
                >
                  {course.difficulty?.toUpperCase() || 'BEGINNER'}
                </Box>
              </Box>
            </Box>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Courses;