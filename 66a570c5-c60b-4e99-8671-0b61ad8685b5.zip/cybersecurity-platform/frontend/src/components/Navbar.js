import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Menu,
  MenuItem,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Avatar,
  Divider,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard,
  School,
  Terminal as TerminalIcon,
  Flag,
  Leaderboard,
  Person,
  Logout,
  Lock,
  Close,
  Security,
  Code,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';

const Navbar = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const menuItems = [
    { text: 'Dashboard', icon: <Dashboard />, path: '/' },
    { text: 'Courses', icon: <School />, path: '/courses' },
    { text: 'Terminal', icon: <TerminalIcon />, path: '/terminal' },
    { text: 'CTF', icon: <Flag />, path: '/ctf' },
    { text: 'Leaderboard', icon: <Leaderboard />, path: '/leaderboard' },
  ];

  const drawerContent = (
    <Box>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          p: 2,
        }}
      >
        <Typography variant="h6" sx={{ color: '#00ff88' }}>
          <Security sx={{ verticalAlign: 'middle', mr: 1 }} />
          CyberSec
        </Typography>
        <IconButton onClick={handleDrawerToggle} sx={{ color: '#ffffff' }}>
          <Close />
        </IconButton>
      </Box>

      <Divider sx={{ bgcolor: '#4a5568' }} />

      <List sx={{ px: 2 }}>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.text}
            onClick={() => {
              navigate(item.path);
              handleDrawerToggle();
            }}
            sx={{
              mb: 1,
              borderRadius: 2,
              bgcolor: location.pathname === item.path ? '#00ff8820' : 'transparent',
              '&:hover': {
                bgcolor: '#00ff8810',
              },
            }}
          >
            <ListItemIcon sx={{ color: location.pathname === item.path ? '#00ff88' : '#a0aec0' }}>
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.text}
              sx={{
                color: location.pathname === item.path ? '#00ff88' : '#ffffff',
              }}
            />
          </ListItem>
        ))}
      </List>

      <Divider sx={{ bgcolor: '#4a5568', my: 2 }} />

      {user && (
        <Box sx={{ px: 2 }}>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<Person />}
            onClick={() => {
              navigate('/profile');
              handleDrawerToggle();
            }}
            sx={{
              mb: 2,
              color: '#00ff88',
              borderColor: '#4a5568',
              justifyContent: 'flex-start',
            }}
          >
            Profile
          </Button>

          <Button
            fullWidth
            variant="outlined"
            startIcon={<Logout />}
            onClick={handleLogout}
            sx={{
              color: '#ef4444',
              borderColor: '#4a5568',
              justifyContent: 'flex-start',
            }}
          >
            Logout
          </Button>
        </Box>
      )}
    </Box>
  );

  if (!user && location.pathname === '/login') {
    return null;
  }

  return (
    <>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          bgcolor: '#0a0e27',
          borderBottom: '1px solid #4a5568',
        }}
      >
        <Toolbar>
          {/* Mobile Menu Button */}
          {isMobile && (
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleDrawerToggle}
              sx={{ mr: 2 }}
            >
              <MenuIcon sx={{ color: '#00ff88' }} />
            </IconButton>
          )}

          {/* Logo */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              cursor: 'pointer',
              flexGrow: 1,
            }}
            onClick={() => navigate('/')}
          >
            <Security sx={{ fontSize: 32, color: '#00ff88', mr: 1 }} />
            <Typography
              variant="h6"
              sx={{
                color: '#ffffff',
                fontWeight: 'bold',
                display: { xs: 'none', sm: 'block' },
              }}
            >
              CyberSec Learning Platform
            </Typography>
          </Box>

          {/* Desktop Navigation */}
          {!isMobile && (
            <Box sx={{ display: 'flex', gap: 1 }}>
              {menuItems.map((item) => (
                <Button
                  key={item.text}
                  onClick={() => navigate(item.path)}
                  sx={{
                    color: location.pathname === item.path ? '#00ff88' : '#a0aec0',
                    fontWeight: location.pathname === item.path ? 'bold' : 'normal',
                    px: 2,
                    py: 1,
                    borderRadius: 2,
                    '&:hover': {
                      bgcolor: '#00ff8810',
                      color: '#00ff88',
                    },
                  }}
                >
                  {item.text}
                </Button>
              ))}
            </Box>
          )}

          {/* User Menu */}
          {user ? (
            <Box sx={{ ml: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
              <IconButton
                onClick={handleMenuOpen}
                sx={{
                  bgcolor: '#00ff8820',
                  '&:hover': { bgcolor: '#00ff8830' },
                }}
              >
                <Avatar sx={{ width: 40, height: 40, bgcolor: '#00ff88', color: '#000' }}>
                  {user.username?.charAt(0).toUpperCase() || 'U'}
                </Avatar>
              </IconButton>

              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
                PaperProps={{
                  sx: {
                    bgcolor: '#1a1f3a',
                    border: '1px solid #4a5568',
                    minWidth: 200,
                  },
                }}
              >
                <MenuItem
                  onClick={() => {
                    navigate('/profile');
                    handleMenuClose();
                  }}
                  sx={{ color: '#ffffff' }}
                >
                  <ListItemIcon>
                    <Person sx={{ color: '#00ff88' }} />
                  </ListItemIcon>
                  <ListItemText>Profile</ListItemText>
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    handleLogout();
                    handleMenuClose();
                  }}
                  sx={{ color: '#ef4444' }}
                >
                  <ListItemIcon>
                    <Logout sx={{ color: '#ef4444' }} />
                  </ListItemIcon>
                  <ListItemText>Logout</ListItemText>
                </MenuItem>
              </Menu>
            </Box>
          ) : (
            <Button
              variant="contained"
              startIcon={<Lock />}
              onClick={() => navigate('/login')}
              sx={{
                ml: 2,
                bgcolor: '#00ff88',
                color: '#000',
                '&:hover': { bgcolor: '#00cc6a' },
              }}
            >
              Login
            </Button>
          )}
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer
        anchor="left"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': {
            width: 280,
            bgcolor: '#0f142b',
            borderRight: '1px solid #4a5568',
          },
        }}
      >
        {drawerContent}
      </Drawer>
    </>
  );
};

export default Navbar;